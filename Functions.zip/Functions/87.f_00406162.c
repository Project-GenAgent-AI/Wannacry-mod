
undefined4 __cdecl FUN_00406162(undefined4 *param_1)

{
  if (param_1 == (undefined4 *)0x0) {
    return 0xffffff9a;
  }
  if (param_1[0x1f] != 0) {
    FUN_00406a97((int)param_1);
  }
  FUN_00405c9f((void *)*param_1);
  free(param_1);
  return 0;
}
