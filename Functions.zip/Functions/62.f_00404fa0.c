
int __cdecl FUN_00404fa0(int *param_1,uint *param_2,int *param_3,int param_4,int param_5)

{
  uint *puVar1;
  int iVar2;
  uint local_8;
  
  local_8 = 0;
  puVar1 = (uint *)(**(code **)(param_5 + 0x20))(*(undefined4 *)(param_5 + 0x28),0x13,4);
  if (puVar1 == (uint *)0x0) {
    iVar2 = -4;
  }
  else {
    iVar2 = FUN_00404c19(param_1,0x13,0x13,0,0,param_3,param_2,param_4,&local_8,puVar1);
    if (iVar2 == -3) {
      *(char **)(param_5 + 0x18) = s_oversubscribed_dynamic_bit_lengt_0040f6e4;
    }
    else if ((iVar2 == -5) || (*param_2 == 0)) {
      *(char **)(param_5 + 0x18) = s_incomplete_dynamic_bit_lengths_t_0040f6c0;
      iVar2 = -3;
    }
    (**(code **)(param_5 + 0x24))(*(undefined4 *)(param_5 + 0x28),puVar1);
  }
  return iVar2;
}
