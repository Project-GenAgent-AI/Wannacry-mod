
undefined4 __cdecl FUN_004010fd(int param_1)

{
  size_t sVar1;
  LSTATUS LVar2;
  int iVar3;
  undefined4 *puVar4;
  wchar_t *pwVar5;
  bool bVar6;
  HKEY hKey;
  BYTE local_2e0;
  undefined4 local_2df;
  wchar_t local_d8 [10];
  undefined4 local_c4 [45];
  DWORD local_10;
  int local_c;
  HKEY local_8;
  
  puVar4 = &DAT_0040e04c;
  pwVar5 = local_d8;
  for (iVar3 = 5; iVar3 != 0; iVar3 = iVar3 + -1) {
    *(undefined4 *)pwVar5 = *puVar4;
    puVar4 = puVar4 + 1;
    pwVar5 = pwVar5 + 2;
  }
  local_2e0 = '\0';
  local_8 = (HKEY)0x0;
  puVar4 = local_c4;
  for (iVar3 = 0x2d; iVar3 != 0; iVar3 = iVar3 + -1) {
    *puVar4 = 0;
    puVar4 = puVar4 + 1;
  }
  puVar4 = &local_2df;
  for (iVar3 = 0x81; iVar3 != 0; iVar3 = iVar3 + -1) {
    *puVar4 = 0;
    puVar4 = puVar4 + 1;
  }
  *(undefined2 *)puVar4 = 0;
  *(undefined1 *)((int)puVar4 + 2) = 0;
  wcscat(local_d8,(wchar_t *)&_Source_0040e034);
  local_c = 0;
  do {
    if (local_c == 0) {
      hKey = (HKEY)0x80000002;
    }
    else {
      hKey = (HKEY)0x80000001;
    }
    RegCreateKeyW(hKey,local_d8,&local_8);
    if (local_8 != (HKEY)0x0) {
      if (param_1 == 0) {
        local_10 = 0x207;
        LVar2 = RegQueryValueExA(local_8,&DAT_0040e030,(LPDWORD)0x0,(LPDWORD)0x0,&local_2e0,
                                 &local_10);
        bVar6 = LVar2 == 0;
        if (bVar6) {
          SetCurrentDirectoryA((LPCSTR)&local_2e0);
        }
      }
      else {
        GetCurrentDirectoryA(0x207,(LPSTR)&local_2e0);
        sVar1 = strlen((char *)&local_2e0);
        LVar2 = RegSetValueExA(local_8,&DAT_0040e030,0,1,&local_2e0,sVar1 + 1);
        bVar6 = LVar2 == 0;
      }
      RegCloseKey(local_8);
      if (bVar6) {
        return 1;
      }
    }
    local_c = local_c + 1;
    if (1 < local_c) {
      return 0;
    }
  } while( true );
}
