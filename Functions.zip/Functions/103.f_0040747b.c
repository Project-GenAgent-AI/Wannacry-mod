
undefined4 __fastcall FUN_0040747b(int *param_1)

{
  if (param_1[1] != -1) {
    FUN_00406a97(*param_1);
  }
  param_1[1] = -1;
  if ((undefined4 *)*param_1 != (undefined4 *)0x0) {
    FUN_00406162((undefined4 *)*param_1);
  }
  *param_1 = 0;
  return 0;
}
