
void * __thiscall FUN_0040135e(void *this,byte param_1)

{
  FUN_0040137a();
  if ((param_1 & 1) != 0) {
    operator_delete(this);
  }
  return this;
}
