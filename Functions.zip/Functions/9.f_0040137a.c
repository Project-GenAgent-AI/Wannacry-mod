
void FUN_0040137a(void)

{
  undefined4 *extraout_ECX;
  int unaff_EBP;
  
  FUN_004076c8();
  *(undefined4 **)(unaff_EBP + -0x10) = extraout_ECX;
  *extraout_ECX = &PTR_FUN_004081d8;
  *(undefined4 *)(unaff_EBP + -4) = 2;
  FUN_004013ce((int)extraout_ECX);
  *(undefined1 *)(unaff_EBP + -4) = 1;
  FUN_00402a6f(extraout_ECX + 0x15);
  *(undefined1 *)(unaff_EBP + -4) = 0;
  FUN_0040181b(extraout_ECX + 0xb);
  *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
  FUN_0040181b(extraout_ECX + 1);
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}

