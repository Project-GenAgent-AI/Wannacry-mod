
undefined4 __cdecl
FUN_00404c19(int *param_1,uint param_2,uint param_3,int param_4,int param_5,int *param_6,
            uint *param_7,int param_8,uint *param_9,uint *param_10)

{
  undefined4 uVar1;
  uint *puVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  uint *puVar6;
  uint *puVar7;
  int iVar8;
  int *piVar9;
  undefined4 *puVar10;
  byte bVar11;
  int iVar12;
  uint uVar13;
  uint *puVar14;
  uint uVar15;
  int local_f4 [15];
  uint local_b8 [16];
  uint local_78 [19];
  undefined4 local_2c;
  uint local_28;
  uint *local_24;
  int local_20;
  uint *local_1c;
  uint local_18;
  uint *local_14;
  uint local_10;
  int local_c;
  uint *local_8;
  
  puVar6 = param_7;
  local_78[0] = 0;
  local_78[1] = 0;
  local_78[2] = 0;
  local_78[3] = 0;
  local_78[4] = 0;
  local_78[5] = 0;
  local_78[6] = 0;
  local_78[7] = 0;
  local_78[8] = 0;
  local_78[9] = 0;
  local_78[10] = 0;
  local_78[0xb] = 0;
  local_78[0xc] = 0;
  local_78[0xd] = 0;
  local_78[0xe] = 0;
  local_78[0xf] = 0;
  piVar9 = param_1;
  uVar13 = param_2;
  do {
    iVar12 = *piVar9;
    piVar9 = piVar9 + 1;
    local_78[iVar12] = local_78[iVar12] + 1;
    uVar13 = uVar13 - 1;
  } while (uVar13 != 0);
  if (local_78[0] == param_2) {
    *param_6 = 0;
    *param_7 = 0;
  }
  else {
    puVar7 = (uint *)0x1;
    puVar14 = local_78;
    param_7 = (uint *)*param_7;
    do {
      puVar14 = puVar14 + 1;
      if (*puVar14 != 0) break;
      puVar7 = (uint *)((int)puVar7 + 1);
    } while (puVar7 < (uint *)0x10);
    local_8 = puVar7;
    if (param_7 < puVar7) {
      param_7 = puVar7;
    }
    puVar14 = local_78 + 0xf;
    puVar2 = (uint *)0xf;
    do {
      if (*puVar14 != 0) break;
      puVar2 = (uint *)((int)puVar2 - 1);
      puVar14 = puVar14 + -1;
    } while (puVar2 != (uint *)0x0);
    local_1c = puVar2;
    if (puVar2 < param_7) {
      param_7 = puVar2;
    }
    iVar12 = 1 << ((byte)puVar7 & 0x1f);
    *puVar6 = (uint)param_7;
    if (puVar7 < puVar2) {
      puVar6 = local_78 + (int)puVar7;
      do {
        uVar13 = *puVar6;
        if ((int)(iVar12 - uVar13) < 0) {
          return 0xfffffffd;
        }
        puVar7 = (uint *)((int)puVar7 + 1);
        puVar6 = puVar6 + 1;
        iVar12 = (iVar12 - uVar13) * 2;
      } while (puVar7 < puVar2);
    }
    local_78[0x11] = iVar12 - local_78[(int)puVar2];
    if ((int)local_78[0x11] < 0) {
      return 0xfffffffd;
    }
    local_b8[1] = 0;
    local_78[(int)puVar2] = local_78[(int)puVar2] + local_78[0x11];
    iVar8 = 0;
    iVar12 = (int)puVar2 - 1;
    if (iVar12 != 0) {
      iVar4 = 0;
      do {
        iVar8 = iVar8 + *(int *)((int)local_78 + iVar4 + 4);
        iVar12 = iVar12 + -1;
        *(int *)((int)local_b8 + iVar4 + 8) = iVar8;
        iVar4 = iVar4 + 4;
      } while (iVar12 != 0);
    }
    uVar13 = 0;
    do {
      iVar12 = *param_1;
      param_1 = param_1 + 1;
      if (iVar12 != 0) {
        uVar15 = local_b8[iVar12];
        param_10[uVar15] = uVar13;
        local_b8[iVar12] = uVar15 + 1;
      }
      uVar13 = uVar13 + 1;
    } while (uVar13 < param_2);
    uVar13 = local_b8[(int)puVar2];
    local_c = -1;
    local_10 = 0;
    local_14 = param_10;
    iVar12 = -(int)param_7;
    local_b8[0] = 0;
    local_f4[0] = 0;
    local_20 = 0;
    param_1 = (int *)0x0;
    if ((int)local_8 <= (int)local_1c) {
      local_78[0x12] = (int)local_8 - 1;
      local_24 = local_78 + (int)local_8;
      uVar15 = local_28;
      do {
        uVar3 = *local_24;
        local_18 = uVar3 - 1;
        uVar1 = local_2c;
        while (uVar3 != 0) {
          local_2c._2_2_ = (undefined2)((uint)uVar1 >> 0x10);
          local_78[0x10] = (int)param_7 + iVar12;
          if ((int)local_78[0x10] < (int)local_8) {
            do {
              local_2c = uVar1;
              iVar8 = local_c;
              local_c = local_c + 1;
              iVar12 = iVar12 + (int)param_7;
              local_78[0x10] = local_78[0x10] + (int)param_7;
              param_1 = (int *)((int)local_1c - iVar12);
              if (param_7 < param_1) {
                param_1 = (int *)param_7;
              }
              piVar9 = (int *)((int)local_8 - iVar12);
              uVar3 = 1 << ((byte)piVar9 & 0x1f);
              if ((local_18 + 1 < uVar3) &&
                 (iVar4 = uVar3 + (-1 - local_18), puVar6 = local_24, piVar9 < param_1)) {
                while (piVar9 = (int *)((int)piVar9 + 1), piVar9 < param_1) {
                  uVar3 = puVar6[1];
                  puVar6 = puVar6 + 1;
                  uVar5 = iVar4 * 2;
                  if (uVar5 < uVar3 || uVar5 - uVar3 == 0) break;
                  iVar4 = uVar5 - uVar3;
                }
              }
              param_1 = (int *)(1 << ((byte)piVar9 & 0x1f));
              uVar3 = *param_9 + (int)param_1;
              if (0x5a0 < uVar3) {
                return 0xfffffffd;
              }
              local_20 = param_8 + *param_9 * 8;
              local_f4[local_c] = local_20;
              uVar5 = local_10;
              iVar4 = local_20;
              *param_9 = uVar3;
              if (local_c == 0) {
                *param_6 = local_20;
              }
              else {
                local_b8[local_c] = local_10;
                local_2c._0_2_ = CONCAT11((char)param_7,(byte)piVar9);
                uVar5 = uVar5 >> ((char)iVar12 - (char)param_7 & 0x1fU);
                iVar8 = local_f4[iVar8];
                uVar15 = (iVar4 - iVar8 >> 3) - uVar5;
                *(undefined4 *)(iVar8 + uVar5 * 8) = local_2c;
                *(uint *)(iVar8 + 4 + uVar5 * 8) = uVar15;
              }
              uVar1 = local_2c;
            } while ((int)local_78[0x10] < (int)local_8);
          }
          uVar3 = local_18;
          bVar11 = (byte)iVar12;
          if (local_14 < param_10 + uVar13) {
            uVar15 = *local_14;
            if (uVar15 < param_3) {
              local_2c._0_1_ = (-(uVar15 < 0x100) & 0xa0U) + 0x60;
            }
            else {
              iVar8 = (uVar15 - param_3) * 4;
              local_2c._0_1_ = *(char *)(iVar8 + param_5) + 'P';
              uVar15 = *(uint *)(iVar8 + param_4);
            }
            local_14 = local_14 + 1;
          }
          else {
            local_2c._0_1_ = -0x40;
          }
          local_2c = CONCAT31(CONCAT21(local_2c._2_2_,(char)local_8 - bVar11),(char)local_2c);
          iVar8 = 1 << ((char)local_8 - bVar11 & 0x1f);
          piVar9 = (int *)(local_10 >> (bVar11 & 0x1f));
          if (piVar9 < param_1) {
            puVar10 = (undefined4 *)(local_20 + (int)piVar9 * 8);
            do {
              piVar9 = (int *)((int)piVar9 + iVar8);
              *puVar10 = local_2c;
              puVar10[1] = uVar15;
              puVar10 = puVar10 + iVar8 * 2;
            } while (piVar9 < param_1);
          }
          uVar5 = 1 << ((byte)local_78[0x12] & 0x1f);
          while ((local_10 & uVar5) != 0) {
            local_10 = local_10 ^ uVar5;
            uVar5 = uVar5 >> 1;
          }
          local_10 = local_10 ^ uVar5;
          for (puVar6 = local_b8 + local_c;
              ((1 << ((byte)iVar12 & 0x1f)) - 1U & local_10) != *puVar6; puVar6 = puVar6 + -1) {
            local_c = local_c + -1;
            iVar12 = iVar12 - (int)param_7;
          }
          local_18 = local_18 - 1;
          uVar1 = local_2c;
        }
        local_8 = (uint *)((int)local_8 + 1);
        local_24 = local_24 + 1;
        local_78[0x12] = local_78[0x12] + 1;
        local_2c = uVar1;
      } while ((int)local_8 <= (int)local_1c);
    }
    if ((local_78[0x11] != 0) && (local_1c != (uint *)0x1)) {
      return 0xfffffffb;
    }
  }
  return 0;
}
