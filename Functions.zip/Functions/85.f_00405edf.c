
int __cdecl FUN_00405edf(char *param_1)

{
  int iVar1;
  uint uVar2;
  void *_Memory;
  uint uVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  int local_10;
  uint local_c;
  uint local_8;
  
  iVar1 = FUN_00405d0e(param_1,0,2);
  if (iVar1 == 0) {
    uVar2 = FUN_00405cdd(param_1);
    local_8 = 0xffff;
    if (uVar2 < 0xffff) {
      local_8 = uVar2;
    }
    _Memory = malloc(0x404);
    if (_Memory != (void *)0x0) {
      local_10 = -1;
      local_c = 4;
      if (4 < local_8) {
        while( true ) {
          uVar3 = local_c + 0x400;
          local_c = local_8;
          if (uVar3 <= local_8) {
            local_c = uVar3;
          }
          iVar1 = uVar2 - local_c;
          uVar3 = 0x404;
          if (uVar2 - iVar1 < 0x405) {
            uVar3 = uVar2 - iVar1;
          }
          iVar4 = FUN_00405d0e(param_1,iVar1,0);
          if ((iVar4 != 0) || (uVar5 = FUN_00405d8a(_Memory,uVar3,1,param_1), uVar5 != 1)) break;
          iVar4 = uVar3 - 3;
          do {
            iVar6 = iVar4;
            iVar4 = iVar6 + -1;
            if (iVar6 < 0) goto LAB_00405fc0;
          } while ((((*(char *)(iVar4 + (int)_Memory) != 'P') ||
                    (*(char *)(iVar6 + (int)_Memory) != 'K')) ||
                   (*(char *)(iVar6 + 1 + (int)_Memory) != '\x05')) ||
                  (*(char *)(iVar6 + 2 + (int)_Memory) != '\x06'));
          local_10 = iVar4 + iVar1;
LAB_00405fc0:
          if ((local_10 != 0) || (local_8 <= local_c)) break;
        }
      }
      free(_Memory);
      return local_10;
    }
  }
  return -1;
}
