
undefined4 __cdecl FUN_00401ce8(undefined4 param_1)

{
  undefined4 uVar1;
  SC_HANDLE hService;
  char local_410 [1024];
  SC_HANDLE local_10;
  undefined4 local_c;
  SC_HANDLE local_8;
  
  local_c = 0;
  local_8 = OpenSCManagerA((LPCSTR)0x0,(LPCSTR)0x0,0xf003f);
  if (local_8 == (SC_HANDLE)0x0) {
    uVar1 = 0;
  }
  else {
    local_10 = OpenServiceA(local_8,(LPCSTR)&lpMultiByteStr_0040f8ac,0xf01ff);
    if (local_10 == (SC_HANDLE)0x0) {
      sprintf(local_410,s_cmd.exe_/c_"%s"_0040f42c,param_1);
      hService = CreateServiceA(local_8,(LPCSTR)&lpMultiByteStr_0040f8ac,
                                (LPCSTR)&lpMultiByteStr_0040f8ac,0xf01ff,0x10,2,1,local_410,
                                (LPCSTR)0x0,(LPDWORD)0x0,(LPCSTR)0x0,(LPCSTR)0x0,(LPCSTR)0x0);
      uVar1 = local_c;
      if (hService != (SC_HANDLE)0x0) {
        StartServiceA(hService,0,(LPCSTR *)0x0);
        CloseServiceHandle(hService);
        local_c = 1;
        uVar1 = local_c;
      }
    }
    else {
      StartServiceA(local_10,0,(LPCSTR *)0x0);
      CloseServiceHandle(local_10);
      uVar1 = 1;
    }
    CloseServiceHandle(local_8);
  }
  return uVar1;
}

