
uint __cdecl FUN_00405588(int param_1)

{
  uint uVar1;
  
  uVar1 = *(uint *)(param_1 + 8) & 0xfffd | 2;
  return (uVar1 ^ 1) * uVar1 >> 8 & 0xff;
}
