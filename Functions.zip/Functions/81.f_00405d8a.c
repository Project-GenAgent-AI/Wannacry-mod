
uint __cdecl FUN_00405d8a(void *param_1,uint param_2,int param_3,char *param_4)

{
  int *piVar1;
  int iVar2;
  char *pcVar3;
  BOOL BVar4;
  void *_Size;
  
  pcVar3 = param_4;
  _Size = (void *)(param_2 * param_3);
  if (*param_4 == '\0') {
    iVar2 = *(int *)(param_4 + 0x1c);
    if (*(uint *)(param_4 + 0x18) < (uint)(iVar2 + (int)_Size)) {
      _Size = (void *)(*(uint *)(param_4 + 0x18) - iVar2);
    }
    memcpy(param_1,(void *)(*(int *)(param_4 + 0x14) + iVar2),(size_t)_Size);
    piVar1 = (int *)(pcVar3 + 0x1c);
    *piVar1 = *piVar1 + (int)_Size;
    param_1 = _Size;
  }
  else {
    BVar4 = ReadFile(*(HANDLE *)(param_4 + 4),param_1,(DWORD)_Size,(LPDWORD)&param_1,
                     (LPOVERLAPPED)0x0);
    if (BVar4 == 0) {
      pcVar3[8] = '\x01';
    }
  }
  return (uint)param_1 / param_2;
}
