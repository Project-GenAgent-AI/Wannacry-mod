
undefined4 __cdecl FUN_00406a97(int param_1)

{
  undefined4 *_Memory;
  undefined4 local_4;
  
  local_4 = 0;
  if ((param_1 == 0) || (_Memory = *(undefined4 **)(param_1 + 0x7c), _Memory == (undefined4 *)0x0))
  {
    local_4 = 0xffffff9a;
  }
  else {
    if ((_Memory[0x17] == 0) && (_Memory[0x14] != _Memory[0x15])) {
      local_4 = 0xffffff97;
    }
    if ((void *)*_Memory != (void *)0x0) {
      free((void *)*_Memory);
      *_Memory = 0;
    }
    *_Memory = 0;
    if (_Memory[0x10] != 0) {
      FUN_00405739((int)(_Memory + 1));
    }
    _Memory[0x10] = 0;
    free(_Memory);
    *(undefined4 *)(param_1 + 0x7c) = 0;
  }
  return local_4;
}
