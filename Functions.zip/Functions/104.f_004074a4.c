
undefined4 * FUN_004074a4(void)

{
  void *this;
  undefined4 *this_00;
  undefined4 *puVar1;
  int unaff_EBP;
  
  FUN_004076c8();
  this = operator_new(0x244);
  *(void **)(unaff_EBP + -0x10) = this;
  *(undefined4 *)(unaff_EBP + -4) = 0;
  if (this == (void *)0x0) {
    this_00 = (undefined4 *)0x0;
  }
  else {
    this_00 = FUN_00407527(this,*(char **)(unaff_EBP + 0x14));
  }
  *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
  DAT_0040f938 = FUN_00406b8e(this_00,*(LPCSTR *)(unaff_EBP + 8),*(undefined4 *)(unaff_EBP + 0xc),
                              *(int *)(unaff_EBP + 0x10));
  if (DAT_0040f938 == (int *)0x0) {
    puVar1 = (undefined4 *)operator_new(8);
    *puVar1 = 1;
    puVar1[1] = this_00;
  }
  else {
    if (this_00 != (undefined4 *)0x0) {
      FUN_00407572((int)this_00);
      operator_delete(this_00);
    }
    puVar1 = (undefined4 *)0x0;
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return puVar1;
}
