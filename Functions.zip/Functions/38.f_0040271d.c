
undefined4 __cdecl FUN_0040271d(int *param_1)

{
  int iVar1;
  undefined4 *puVar2;
  
  iVar1 = param_1[1];
  if (*(int *)(*param_1 + 0xc0) == 0) {
    return 1;
  }
  puVar2 = *(undefined4 **)(*(int *)(*param_1 + 0xc0) + 0xc + iVar1);
  if (puVar2 != (undefined4 *)0x0) {
    for (; (code *)*puVar2 != (code *)0x0; puVar2 = puVar2 + 1) {
      (*(code *)*puVar2)(iVar1,1,0);
    }
  }
  return 1;
}
