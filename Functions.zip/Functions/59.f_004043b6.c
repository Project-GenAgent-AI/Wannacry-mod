
void __cdecl FUN_004043b6(uint *param_1,int *param_2,uint param_3)

{
  uint *puVar1;
  byte bVar2;
  void *pvVar3;
  void *pvVar4;
  uint *puVar5;
  int *piVar6;
  int iVar7;
  undefined4 uVar8;
  uint uVar9;
  byte *_Src;
  int local_30;
  int local_2c;
  undefined4 local_28;
  undefined4 local_24;
  undefined4 local_20;
  undefined4 local_1c;
  uint local_18;
  uint local_14;
  uint local_10;
  void *local_c;
  uint local_8;
  
  piVar6 = param_2;
  puVar5 = param_1;
  local_c = (void *)param_1[0xd];
  local_8 = param_2[1];
  _Src = (byte *)*param_2;
  param_2 = (int *)param_1[7];
  if (local_c < (void *)param_1[0xc]) {
    local_14 = (int)param_1[0xc] + (-1 - (int)local_c);
  }
  else {
    local_14 = param_1[0xb] - (int)local_c;
  }
  uVar9 = *param_1;
  param_1 = (uint *)param_1[8];
  while (uVar9 < 10) {
    switch((&switchD_00404408::switchdataD_00404bbd)[uVar9]) {
    case (undefined *)0x40440f:
      for (; param_2 < (int *)0x3; param_2 = param_2 + 2) {
        if (local_8 == 0) goto LAB_00404a58;
        param_3 = 0;
        local_8 = local_8 - 1;
        param_1 = (uint *)((uint)param_1 | (uint)*_Src << ((byte)param_2 & 0x1f));
        _Src = _Src + 1;
      }
      uVar9 = ((uint)param_1 & 7) >> 1;
      puVar5[6] = (uint)param_1 & 1;
      if (uVar9 == 0) {
        *puVar5 = 1;
        uVar9 = (int)param_2 - 3U & 7;
        param_1 = (uint *)(((uint)param_1 >> 3) >> (sbyte)uVar9);
        param_2 = (int *)(((int)param_2 - 3U) - uVar9);
        break;
      }
      if (uVar9 == 1) {
        FUN_00405122(&local_28,&local_24,&local_20,&local_1c);
        uVar9 = FUN_00403cc8((char)local_28,(char)local_24,local_20,local_1c,(int)piVar6);
        puVar5[1] = uVar9;
        if (uVar9 == 0) goto LAB_00404b1c;
        param_1 = (uint *)((uint)param_1 >> 3);
        param_2 = (int *)((int)param_2 + -3);
        *puVar5 = 6;
        break;
      }
      if (uVar9 == 2) {
        param_1 = (uint *)((uint)param_1 >> 3);
        uVar9 = 3;
        param_2 = (int *)((int)param_2 + -3);
        goto LAB_00404469;
      }
      if (uVar9 != 3) break;
      *puVar5 = 9;
      piVar6[6] = (int)s_invalid_block_type_0040f6ac;
      puVar5[8] = (uint)param_1 >> 3;
      param_2 = (int *)((int)param_2 - 3);
      goto LAB_00404a28;
    case (undefined *)0x4044dc:
      for (; param_2 < (int *)0x20; param_2 = param_2 + 2) {
        if (local_8 == 0) goto LAB_00404a58;
        param_3 = 0;
        local_8 = local_8 - 1;
        param_1 = (uint *)((uint)param_1 | (uint)*_Src << ((byte)param_2 & 0x1f));
        _Src = _Src + 1;
      }
      if (~(uint)param_1 >> 0x10 != ((uint)param_1 & 0xffff)) {
        *puVar5 = 9;
        piVar6[6] = (int)s_invalid_stored_block_lengths_0040f68c;
        goto switchD_00404408_caseD_404a1f;
      }
      puVar5[1] = (uint)param_1 & 0xffff;
      param_2 = (int *)0x0;
      param_1 = (uint *)0x0;
      if (puVar5[1] == 0) goto LAB_0040461c;
      uVar9 = 2;
LAB_00404469:
      *puVar5 = uVar9;
      break;
    case (undefined *)0x40453a:
      if (local_8 == 0) {
LAB_00404a58:
        puVar5[8] = (uint)param_1;
        puVar5[7] = (uint)param_2;
        piVar6[1] = 0;
LAB_00404a68:
        iVar7 = *piVar6;
        *piVar6 = (int)_Src;
        piVar6[2] = (int)(_Src + (piVar6[2] - iVar7));
        puVar5[0xd] = (uint)local_c;
        goto LAB_004049e5;
      }
      if (local_14 == 0) {
        local_14 = 0;
        if (local_c == (void *)puVar5[0xb]) {
          pvVar3 = (void *)puVar5[0xc];
          pvVar4 = (void *)puVar5[10];
          if (pvVar4 != pvVar3) {
            if (pvVar4 < pvVar3) {
              local_14 = (int)pvVar3 + (-1 - (int)pvVar4);
            }
            else {
              local_14 = (int)puVar5[0xb] - (int)pvVar4;
            }
            local_c = pvVar4;
            if (local_14 != 0) goto LAB_004045d7;
          }
        }
        puVar5[0xd] = (uint)local_c;
        param_3 = FUN_00403bd6((int)puVar5,piVar6,param_3);
        pvVar3 = (void *)puVar5[0xc];
        local_c = (void *)puVar5[0xd];
        if (local_c < pvVar3) {
          local_14 = (int)pvVar3 + (-1 - (int)local_c);
        }
        else {
          local_14 = puVar5[0xb] - (int)local_c;
        }
        if (local_c == (void *)puVar5[0xb]) {
          pvVar4 = (void *)puVar5[10];
          if (pvVar4 != pvVar3) {
            local_c = pvVar4;
            if (pvVar4 < pvVar3) {
              local_14 = (int)pvVar3 + (-1 - (int)pvVar4);
            }
            else {
              local_14 = (int)puVar5[0xb] - (int)pvVar4;
            }
          }
        }
        if (local_14 == 0) {
          puVar5[8] = (uint)param_1;
          puVar5[7] = (uint)param_2;
          piVar6[1] = local_8;
          goto LAB_00404a68;
        }
      }
LAB_004045d7:
      local_10 = puVar5[1];
      param_3 = 0;
      if (local_8 < local_10) {
        local_10 = local_8;
      }
      if (local_14 < local_10) {
        local_10 = local_14;
      }
      memcpy(local_c,_Src,local_10);
      local_8 = local_8 - local_10;
      local_c = (void *)((int)local_c + local_10);
      local_14 = local_14 - local_10;
      _Src = _Src + local_10;
      puVar1 = puVar5 + 1;
      *puVar1 = *puVar1 - local_10;
      if (*puVar1 == 0) {
LAB_0040461c:
        uVar9 = -(uint)(puVar5[6] != 0) & 7;
        goto LAB_00404469;
      }
      break;
    case (undefined *)0x40462b:
      for (; param_2 < (int *)0xe; param_2 = param_2 + 2) {
        if (local_8 == 0) goto LAB_00404a58;
        param_3 = 0;
        local_8 = local_8 - 1;
        param_1 = (uint *)((uint)param_1 | (uint)*_Src << ((byte)param_2 & 0x1f));
        _Src = _Src + 1;
      }
      puVar5[1] = (uint)param_1 & 0x3fff;
      if ((0x1d < ((uint)param_1 & 0x1f)) || (0x3a0 < ((uint)param_1 & 0x3e0))) {
        *puVar5 = 9;
        piVar6[6] = (int)s_too_many_length_or_distance_symb_0040f668;
        goto switchD_00404408_caseD_404a1f;
      }
      uVar9 = (*(code *)piVar6[8])
                        (piVar6[10],
                         (((uint)param_1 & 0x3fff) >> 5 & 0x1f) + 0x102 + ((uint)param_1 & 0x1f),4);
      puVar5[3] = uVar9;
      if (uVar9 != 0) {
        param_1 = (uint *)((uint)param_1 >> 0xe);
        param_2 = (int *)((int)param_2 + -0xe);
        puVar5[2] = 0;
        *puVar5 = 4;
        goto switchD_00404408_caseD_4046b8;
      }
LAB_00404b1c:
      param_3 = 0xfffffffc;
      puVar5[8] = (uint)param_1;
      puVar5[7] = (uint)param_2;
      piVar6[1] = local_8;
      iVar7 = *piVar6;
      *piVar6 = (int)_Src;
      piVar6[2] = (int)(_Src + (piVar6[2] - iVar7));
      puVar5[0xd] = (uint)local_c;
      goto LAB_004049e5;
    case (undefined *)0x4046b8:
switchD_00404408_caseD_4046b8:
      if (puVar5[2] < (puVar5[1] >> 10) + 4) {
        do {
          for (; param_2 < (int *)0x3; param_2 = param_2 + 2) {
            if (local_8 == 0) goto LAB_00404a58;
            param_3 = 0;
            local_8 = local_8 - 1;
            param_1 = (uint *)((uint)param_1 | (uint)*_Src << ((byte)param_2 & 0x1f));
            _Src = _Src + 1;
          }
          uVar9 = (uint)param_1 & 7;
          param_2 = (int *)((int)param_2 + -3);
          param_1 = (uint *)((uint)param_1 >> 3);
          *(uint *)(puVar5[3] + *(int *)(&DAT_0040cdf0 + puVar5[2] * 4) * 4) = uVar9;
          puVar5[2] = puVar5[2] + 1;
        } while (puVar5[2] < (puVar5[1] >> 10) + 4);
      }
      while (puVar5[2] < 0x13) {
        *(undefined4 *)(puVar5[3] + *(int *)(&DAT_0040cdf0 + puVar5[2] * 4) * 4) = 0;
        puVar5[2] = puVar5[2] + 1;
      }
      puVar5[4] = 7;
      local_10 = FUN_00404fa0((int *)puVar5[3],puVar5 + 4,(int *)(puVar5 + 5),puVar5[9],(int)piVar6)
      ;
      if (local_10 == 0) {
        puVar5[2] = 0;
        *puVar5 = 5;
        goto switchD_00404408_caseD_40476e;
      }
      goto LAB_00404ae0;
    case (undefined *)0x40476e:
switchD_00404408_caseD_40476e:
      while (puVar5[2] < (puVar5[1] >> 5 & 0x1f) + 0x102 + (puVar5[1] & 0x1f)) {
        for (; param_2 < (int *)puVar5[4]; param_2 = param_2 + 2) {
          if (local_8 == 0) goto LAB_00404a58;
          param_3 = 0;
          local_8 = local_8 - 1;
          param_1 = (uint *)((uint)param_1 | (uint)*_Src << ((byte)param_2 & 0x1f));
          _Src = _Src + 1;
        }
        local_18 = *(uint *)(puVar5[5] + 4 +
                            (*(uint *)(&DAT_0040bca8 + (int)puVar5[4] * 4) & (uint)param_1) * 8);
        bVar2 = *(byte *)(puVar5[5] +
                          (*(uint *)(&DAT_0040bca8 + (int)puVar5[4] * 4) & (uint)param_1) * 8 + 1);
        local_10 = (uint)bVar2;
        if (local_18 < 0x10) {
          param_1 = (uint *)((uint)param_1 >> (bVar2 & 0x1f));
          param_2 = (int *)((int)param_2 - local_10);
          *(uint *)(puVar5[3] + puVar5[2] * 4) = local_18;
          puVar5[2] = puVar5[2] + 1;
        }
        else {
          if (local_18 == 0x12) {
            iVar7 = 7;
          }
          else {
            iVar7 = local_18 - 0xe;
          }
          local_14 = ((local_18 != 0x12) - 1 & 8) + 3;
          for (; param_2 < (int *)(iVar7 + local_10); param_2 = param_2 + 2) {
            if (local_8 == 0) goto LAB_00404a58;
            param_3 = 0;
            local_8 = local_8 - 1;
            param_1 = (uint *)((uint)param_1 | (uint)*_Src << ((byte)param_2 & 0x1f));
            _Src = _Src + 1;
          }
          uVar9 = (uint)param_1 >> (bVar2 & 0x1f);
          local_14 = local_14 + (*(uint *)(&DAT_0040bca8 + iVar7 * 4) & uVar9);
          param_1 = (uint *)(uVar9 >> ((byte)iVar7 & 0x1f));
          uVar9 = puVar5[2];
          param_2 = (int *)((int)param_2 - (iVar7 + local_10));
          if ((puVar5[1] >> 5 & 0x1f) + 0x102 + (puVar5[1] & 0x1f) < local_14 + uVar9) {
LAB_00404a94:
            (*(code *)piVar6[9])(piVar6[10],puVar5[3]);
            *puVar5 = 9;
            piVar6[6] = (int)s_invalid_bit_length_repeat_0040f64c;
            puVar5[8] = (uint)param_1;
            puVar5[7] = (uint)param_2;
            piVar6[1] = local_8;
            iVar7 = *piVar6;
            *piVar6 = (int)_Src;
            piVar6[2] = (int)(_Src + (piVar6[2] - iVar7));
            puVar5[0xd] = (uint)local_c;
            FUN_00403bd6((int)puVar5,piVar6,-3);
            return;
          }
          if (local_18 == 0x10) {
            if (uVar9 == 0) goto LAB_00404a94;
            uVar8 = *(undefined4 *)((puVar5[3] - 4) + uVar9 * 4);
          }
          else {
            uVar8 = 0;
          }
          do {
            *(undefined4 *)(puVar5[3] + uVar9 * 4) = uVar8;
            uVar9 = uVar9 + 1;
            local_14 = local_14 - 1;
          } while (local_14 != 0);
          puVar5[2] = uVar9;
          local_14 = 0;
        }
      }
      puVar5[5] = 0;
      local_18 = 9;
      local_14 = 6;
      local_10 = FUN_0040501f((puVar5[1] & 0x1f) + 0x101,(puVar5[1] >> 5 & 0x1f) + 1,
                              (int *)puVar5[3],&local_18,&local_14,&local_30,&local_2c,puVar5[9],
                              (int)piVar6);
      if (local_10 == 0) {
        uVar9 = FUN_00403cc8((char)local_18,(char)local_14,local_30,local_2c,(int)piVar6);
        if (uVar9 == 0) goto LAB_00404b1c;
        puVar5[1] = uVar9;
        (*(code *)piVar6[9])(piVar6[10],puVar5[3]);
        *puVar5 = 6;
        goto switchD_00404408_caseD_404935;
      }
LAB_00404ae0:
      if (local_10 == 0xfffffffd) {
        (*(code *)piVar6[9])(piVar6[10],puVar5[3]);
        *puVar5 = 9;
      }
      puVar5[8] = (uint)param_1;
      puVar5[7] = (uint)param_2;
      piVar6[1] = local_8;
      iVar7 = *piVar6;
      *piVar6 = (int)_Src;
      piVar6[2] = (int)(_Src + (piVar6[2] - iVar7));
      puVar5[0xd] = (uint)local_c;
      param_3 = local_10;
      goto LAB_004049e5;
    case (undefined *)0x404935:
switchD_00404408_caseD_404935:
      puVar5[8] = (uint)param_1;
      puVar5[7] = (uint)param_2;
      piVar6[1] = local_8;
      iVar7 = *piVar6;
      *piVar6 = (int)_Src;
      piVar6[2] = (int)(_Src + (piVar6[2] - iVar7));
      puVar5[0xd] = (uint)local_c;
      param_3 = FUN_00403cfc((uint)puVar5,piVar6,param_3);
      if (param_3 != 1) goto LAB_004049e5;
      param_3 = 0;
      FUN_004042af(puVar5[1],(int)piVar6);
      local_8 = piVar6[1];
      _Src = (byte *)*piVar6;
      param_1 = (uint *)puVar5[8];
      param_2 = (int *)puVar5[7];
      local_c = (void *)puVar5[0xd];
      if (local_c < (void *)puVar5[0xc]) {
        local_14 = (int)puVar5[0xc] + (-1 - (int)local_c);
      }
      else {
        local_14 = puVar5[0xb] - (int)local_c;
      }
      if (puVar5[6] != 0) {
        *puVar5 = 7;
        goto switchD_00404408_caseD_404b4a;
      }
      *puVar5 = 0;
      break;
    case (undefined *)0x404a1f:
switchD_00404408_caseD_404a1f:
      puVar5[8] = (uint)param_1;
LAB_00404a28:
      puVar5[7] = (uint)param_2;
      piVar6[1] = local_8;
      iVar7 = *piVar6;
      *piVar6 = (int)_Src;
      param_3 = 0xfffffffd;
      piVar6[2] = (int)(_Src + (piVar6[2] - iVar7));
      puVar5[0xd] = (uint)local_c;
      goto LAB_004049e5;
    case (undefined *)0x404b4a:
switchD_00404408_caseD_404b4a:
      puVar5[0xd] = (uint)local_c;
      param_3 = FUN_00403bd6((int)puVar5,piVar6,param_3);
      local_c = (void *)puVar5[0xd];
      if ((void *)puVar5[0xc] == local_c) {
        *puVar5 = 8;
        goto switchD_00404408_caseD_404b95;
      }
      puVar5[8] = (uint)param_1;
      puVar5[7] = (uint)param_2;
      piVar6[1] = local_8;
      iVar7 = *piVar6;
      *piVar6 = (int)_Src;
      piVar6[2] = (int)(_Src + (piVar6[2] - iVar7));
      puVar5[0xd] = (uint)local_c;
      goto LAB_004049e5;
    case (undefined *)0x404b95:
switchD_00404408_caseD_404b95:
      param_3 = 1;
      puVar5[8] = (uint)param_1;
      puVar5[7] = (uint)param_2;
      piVar6[1] = local_8;
      iVar7 = *piVar6;
      *piVar6 = (int)_Src;
      piVar6[2] = (int)(_Src + (piVar6[2] - iVar7));
      puVar5[0xd] = (uint)local_c;
      goto LAB_004049e5;
    }
    uVar9 = *puVar5;
  }
  param_3 = 0xfffffffe;
  puVar5[8] = (uint)param_1;
  puVar5[7] = (uint)param_2;
  piVar6[1] = local_8;
  iVar7 = *piVar6;
  *piVar6 = (int)_Src;
  piVar6[2] = (int)(_Src + (piVar6[2] - iVar7));
  puVar5[0xd] = (uint)local_c;
LAB_004049e5:
  FUN_00403bd6((int)puVar5,piVar6,param_3);
  return;
}
