
void __cdecl FUN_004029cc(int *param_1)

{
  int iVar1;
  HANDLE hHeap;
  int iVar2;
  DWORD dwFlags;
  
  if (param_1 != (int *)0x0) {
    if (param_1[4] != 0) {
      (*(code *)(*(int *)(*param_1 + 0x28) + param_1[1]))(param_1[1],0,0);
    }
    if (param_1[2] != 0) {
      iVar2 = 0;
      if (0 < param_1[3]) {
        do {
          iVar1 = *(int *)(param_1[2] + iVar2 * 4);
          if (iVar1 != 0) {
            (*(code *)param_1[0xb])(iVar1,param_1[0xc]);
          }
          iVar2 = iVar2 + 1;
        } while (iVar2 < param_1[3]);
      }
      free((void *)param_1[2]);
    }
    if (param_1[1] != 0) {
      (*(code *)param_1[8])(param_1[1],0,0x8000,param_1[0xc]);
    }
    dwFlags = 0;
    hHeap = GetProcessHeap();
    HeapFree(hHeap,dwFlags,param_1);
  }
  return;
}
