
undefined4 __cdecl FUN_00402457(uint param_1,uint param_2)

{
  if (param_1 < param_2) {
    SetLastError(0xd);
    return 0;
  }
  return 1;
}
