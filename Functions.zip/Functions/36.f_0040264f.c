
int __cdecl FUN_0040264f(int *param_1,int param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_2 + 0x10);
  if (iVar1 == 0) {
    if ((*(uint *)(param_2 + 0x24) & 0x40) != 0) {
      return *(int *)(*param_1 + 0x20);
    }
    if ((*(uint *)(param_2 + 0x24) & 0x80) != 0) {
      iVar1 = *(int *)(*param_1 + 0x24);
    }
  }
  return iVar1;
}
