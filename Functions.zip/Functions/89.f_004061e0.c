
int __cdecl
FUN_004061e0(undefined4 *param_1,int *param_2,int *param_3,void *param_4,uint param_5,void *param_6,
            uint param_7,void *param_8,uint param_9)

{
  undefined4 *puVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  undefined4 *puVar5;
  int *piVar6;
  int local_60 [4];
  uint local_50;
  int local_4c;
  int local_48;
  int local_44;
  undefined4 *local_40;
  uint local_3c;
  uint local_38;
  int local_34;
  int local_30;
  int local_2c;
  int local_28 [6];
  int local_10;
  int local_c;
  int local_8;
  
  puVar1 = param_1;
  local_8 = 0;
  if (param_1 == (undefined4 *)0x0) {
    return -0x66;
  }
  iVar2 = FUN_00405d0e((char *)*param_1,param_1[5] + param_1[3],0);
  if (iVar2 == 0) {
    iVar2 = FUN_00405e6b((char *)*param_1,&local_c);
    if (iVar2 == 0) {
      if (local_c != 0x2014b50) {
        local_8 = -0x67;
      }
    }
    else {
      local_8 = -1;
    }
  }
  else {
    local_8 = -1;
  }
  iVar2 = FUN_00405e27((char *)*param_1,local_60);
  if (iVar2 != 0) {
    local_8 = -1;
  }
  iVar2 = FUN_00405e27((char *)*param_1,local_60 + 1);
  if (iVar2 != 0) {
    local_8 = -1;
  }
  iVar2 = FUN_00405e27((char *)*param_1,local_60 + 2);
  if (iVar2 != 0) {
    local_8 = -1;
  }
  iVar2 = FUN_00405e27((char *)*param_1,local_60 + 3);
  if (iVar2 != 0) {
    local_8 = -1;
  }
  iVar2 = FUN_00405e6b((char *)*param_1,(int *)&local_50);
  if (iVar2 != 0) {
    local_8 = -1;
  }
  FUN_00406191(local_50,local_28);
  iVar2 = FUN_00405e6b((char *)*param_1,&local_4c);
  if (iVar2 != 0) {
    local_8 = -1;
  }
  iVar2 = FUN_00405e6b((char *)*param_1,&local_48);
  if (iVar2 != 0) {
    local_8 = -1;
  }
  iVar2 = FUN_00405e6b((char *)*param_1,&local_44);
  if (iVar2 != 0) {
    local_8 = -1;
  }
  iVar2 = FUN_00405e27((char *)*param_1,(int *)&local_40);
  if (iVar2 != 0) {
    local_8 = -1;
  }
  iVar2 = FUN_00405e27((char *)*param_1,(int *)&local_3c);
  if (iVar2 != 0) {
    local_8 = -1;
  }
  iVar2 = FUN_00405e27((char *)*param_1,(int *)&local_38);
  if (iVar2 != 0) {
    local_8 = -1;
  }
  iVar2 = FUN_00405e27((char *)*param_1,&local_34);
  if (iVar2 != 0) {
    local_8 = -1;
  }
  iVar2 = FUN_00405e27((char *)*param_1,&local_30);
  if (iVar2 != 0) {
    local_8 = -1;
  }
  iVar2 = FUN_00405e6b((char *)*param_1,&local_2c);
  if (iVar2 != 0) {
    local_8 = -1;
  }
  iVar2 = FUN_00405e6b((char *)*param_1,&local_10);
  if (iVar2 != 0) {
    local_8 = -1;
  }
  puVar5 = local_40;
  if (local_8 == 0) {
    if (param_4 != (void *)0x0) {
      puVar5 = (undefined4 *)param_5;
      if (local_40 < param_5) {
        *(undefined1 *)((int)local_40 + (int)param_4) = 0;
        puVar5 = local_40;
      }
      if (((local_40 != (undefined4 *)0x0) && (param_5 != 0)) &&
         (uVar3 = FUN_00405d8a(param_4,(uint)puVar5,1,(char *)*param_1), uVar3 != 1)) {
        local_8 = -1;
      }
      puVar5 = (undefined4 *)((int)local_40 - (int)puVar5);
      if (local_8 != 0) goto LAB_00406435;
    }
    if (param_6 != (void *)0x0) {
      uVar3 = local_3c;
      if (param_7 <= local_3c) {
        uVar3 = param_7;
      }
      if (puVar5 != (undefined4 *)0x0) {
        iVar2 = FUN_00405d0e((char *)*param_1,(int)puVar5,1);
        if (iVar2 == 0) {
          param_1 = (undefined4 *)0x0;
          puVar5 = param_1;
        }
        else {
          local_8 = -1;
        }
      }
      param_1 = puVar5;
      if (((local_3c != 0) && (param_7 != 0)) &&
         (uVar4 = FUN_00405d8a(param_6,uVar3,1,(char *)*puVar1), uVar4 != 1)) {
        local_8 = -1;
      }
      iVar2 = (int)param_1 + (local_3c - uVar3);
      goto LAB_00406438;
    }
  }
LAB_00406435:
  iVar2 = (int)puVar5 + local_3c;
LAB_00406438:
  if (local_8 == 0) {
    if (param_8 != (void *)0x0) {
      uVar3 = param_9;
      if (local_38 < param_9) {
        *(undefined1 *)(local_38 + (int)param_8) = 0;
        uVar3 = local_38;
      }
      if ((iVar2 != 0) && (iVar2 = FUN_00405d0e((char *)*puVar1,iVar2,1), iVar2 != 0)) {
        local_8 = -1;
      }
      if (((local_38 != 0) && (param_9 != 0)) &&
         (uVar3 = FUN_00405d8a(param_8,uVar3,1,(char *)*puVar1), uVar3 != 1)) {
        local_8 = -1;
      }
      if (local_8 != 0) {
        return local_8;
      }
    }
    if (param_2 != (int *)0x0) {
      piVar6 = local_60;
      for (iVar2 = 0x14; iVar2 != 0; iVar2 = iVar2 + -1) {
        *param_2 = *piVar6;
        piVar6 = piVar6 + 1;
        param_2 = param_2 + 1;
      }
    }
    if (param_3 != (int *)0x0) {
      *param_3 = local_10;
    }
  }
  return local_8;
}
