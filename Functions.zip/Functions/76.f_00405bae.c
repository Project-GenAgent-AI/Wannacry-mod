
undefined1 * __cdecl FUN_00405bae(LPCSTR param_1,undefined4 param_2,int param_3,undefined4 *param_4)

{
  undefined1 uVar1;
  LPCSTR hFile;
  DWORD DVar2;
  undefined1 *puVar3;
  bool local_6;
  undefined1 local_5;
  
  if (((param_3 != 1) && (param_3 != 2)) && (param_3 != 3)) {
    *param_4 = 0x10000;
    return (undefined1 *)0x0;
  }
  *param_4 = 0;
  local_6 = false;
  local_5 = 0;
  hFile = param_1;
  uVar1 = 0;
  if (param_3 != 1) {
    hFile = (LPCSTR)0x0;
    if (param_3 != 2) goto LAB_00405c36;
    hFile = (LPCSTR)CreateFileA(param_1,0x80000000,1,(LPSECURITY_ATTRIBUTES)0x0,3,0x80,(HANDLE)0x0);
    if (hFile == (LPCSTR)0xffffffff) {
      *param_4 = 0x200;
      return (undefined1 *)0x0;
    }
    local_5 = 1;
    uVar1 = local_5;
  }
  local_5 = uVar1;
  DVar2 = SetFilePointer(hFile,0,(PLONG)0x0,1);
  local_6 = DVar2 != 0xffffffff;
LAB_00405c36:
  puVar3 = (undefined1 *)operator_new(0x20);
  if ((param_3 == 1) || (param_3 == 2)) {
    *puVar3 = 1;
    puVar3[0x10] = local_5;
    puVar3[1] = local_6;
    *(LPCSTR *)(puVar3 + 4) = hFile;
    puVar3[8] = 0;
    *(undefined4 *)(puVar3 + 0xc) = 0;
    if (local_6 != false) {
      DVar2 = SetFilePointer(hFile,0,(PLONG)0x0,1);
      *(DWORD *)(puVar3 + 0xc) = DVar2;
    }
  }
  else {
    *puVar3 = 0;
    *(LPCSTR *)(puVar3 + 0x14) = param_1;
    puVar3[1] = 1;
    puVar3[0x10] = 0;
    *(undefined4 *)(puVar3 + 0x18) = param_2;
    *(undefined4 *)(puVar3 + 0x1c) = 0;
    *(undefined4 *)(puVar3 + 0xc) = 0;
  }
  *param_4 = 0;
  return puVar3;
}
