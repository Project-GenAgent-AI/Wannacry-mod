
undefined4 * __thiscall FUN_004017ff(void *this,byte param_1)

{
  FUN_0040181b((undefined4 *)this);
  if ((param_1 & 1) != 0) {
    operator_delete(this);
  }
  return (undefined4 *)this;
}
