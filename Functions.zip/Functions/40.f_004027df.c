
int __cdecl FUN_004027df(uint *param_1)

{
  uint uVar1;
  uint *puVar2;
  int iVar3;
  void *pvVar4;
  uint uVar5;
  int *lp;
  uint *puVar6;
  uint uVar7;
  DWORD dwErrCode;
  int local_c;
  
  puVar2 = param_1;
  uVar1 = param_1[1];
  iVar3 = 1;
  local_c = 1;
  if (*(int *)(*param_1 + 0x84) != 0) {
    lp = (int *)(*(int *)(*param_1 + 0x80) + uVar1);
    iVar3 = IsBadReadPtr(lp,0x14);
    while( true ) {
      if (iVar3 != 0) {
        return local_c;
      }
      if (lp[3] == 0) {
        return local_c;
      }
      iVar3 = (*(code *)puVar2[9])(lp[3] + uVar1,puVar2[0xc]);
      if (iVar3 == 0) break;
      pvVar4 = realloc((void *)puVar2[2],puVar2[3] * 4 + 4);
      if (pvVar4 == (void *)0x0) {
        (*(code *)puVar2[0xb])(iVar3,puVar2[0xc]);
        dwErrCode = 0xe;
        goto LAB_004028fd;
      }
      puVar2[2] = (uint)pvVar4;
      *(int *)((int)pvVar4 + puVar2[3] * 4) = iVar3;
      puVar2[3] = puVar2[3] + 1;
      if (*lp == 0) {
        puVar6 = (uint *)(uVar1 + lp[4]);
        param_1 = puVar6;
      }
      else {
        puVar6 = (uint *)(lp[4] + uVar1);
        param_1 = (uint *)(*lp + uVar1);
      }
      for (; uVar5 = *param_1, uVar5 != 0; param_1 = param_1 + 1) {
        if ((uVar5 & 0x80000000) == 0) {
          uVar7 = puVar2[0xc];
          uVar5 = uVar5 + uVar1 + 2;
        }
        else {
          uVar7 = puVar2[0xc];
          uVar5 = uVar5 & 0xffff;
        }
        uVar5 = (*(code *)puVar2[10])(iVar3,uVar5,uVar7);
        *puVar6 = uVar5;
        if (uVar5 == 0) {
          local_c = 0;
          break;
        }
        puVar6 = puVar6 + 1;
      }
      if (local_c == 0) {
        (*(code *)puVar2[0xb])(iVar3,puVar2[0xc]);
        SetLastError(0x7f);
        return 0;
      }
      lp = lp + 5;
      iVar3 = IsBadReadPtr(lp,0x14);
    }
    dwErrCode = 0x7e;
LAB_004028fd:
    SetLastError(dwErrCode);
    local_c = 0;
    iVar3 = local_c;
  }
  return iVar3;
}
