
void __cdecl FUN_00407070(LPCSTR param_1,char *param_2)

{
  char cVar1;
  DWORD DVar2;
  char *pcVar3;
  char *pcVar4;
  char local_20c [260];
  char local_108 [260];
  
  if ((param_1 != (LPCSTR)0x0) && (DVar2 = GetFileAttributesA(param_1), DVar2 == 0xffffffff)) {
    CreateDirectoryA(param_1,(LPSECURITY_ATTRIBUTES)0x0);
  }
  cVar1 = *param_2;
  pcVar3 = param_2;
  pcVar4 = param_2;
  if (cVar1 != '\0') {
    do {
      if ((cVar1 == '/') || (cVar1 == '\\')) {
        pcVar4 = pcVar3;
      }
      cVar1 = pcVar3[1];
      pcVar3 = pcVar3 + 1;
    } while (cVar1 != '\0');
    if (pcVar4 != param_2) {
      memcpy(local_20c,param_2,(int)pcVar4 - (int)param_2);
      local_20c[(int)pcVar4 - (int)param_2] = '\0';
      FUN_00407070(param_1,local_20c);
    }
    local_108[0] = '\0';
    if (param_1 != (LPCSTR)0x0) {
      strcpy(local_108,param_1);
    }
    strcat(local_108,param_2);
    DVar2 = GetFileAttributesA(local_108);
    if (DVar2 == 0xffffffff) {
      CreateDirectoryA(local_108,(LPSECURITY_ATTRIBUTES)0x0);
    }
  }
  return;
}
