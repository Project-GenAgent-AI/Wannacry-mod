
undefined4 __thiscall
FUN_004019e1(void *this,void *param_1,size_t param_2,void *param_3,size_t *param_4)

{
  LPCRITICAL_SECTION lpCriticalSection;
  int iVar1;
  
  if (*(int *)((int)this + 8) != 0) {
    lpCriticalSection = (LPCRITICAL_SECTION)((int)this + 0x10);
    EnterCriticalSection(lpCriticalSection);
    iVar1 = (*DAT_0040f8a4)(*(undefined4 *)((int)this + 8),0,1,0,param_1,&param_2);
    if (iVar1 != 0) {
      LeaveCriticalSection(lpCriticalSection);
      memcpy(param_3,param_1,param_2);
      *param_4 = param_2;
      return 1;
    }
    LeaveCriticalSection(lpCriticalSection);
  }
  return 0;
}
