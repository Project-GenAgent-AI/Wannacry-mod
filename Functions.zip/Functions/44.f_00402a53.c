
undefined4 * __thiscall FUN_00402a53(void *this,byte param_1)

{
  FUN_00402a6f((undefined4 *)this);
  if ((param_1 & 1) != 0) {
    operator_delete(this);
  }
  return (undefined4 *)this;
}
