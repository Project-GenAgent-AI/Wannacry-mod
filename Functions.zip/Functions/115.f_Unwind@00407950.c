
void Unwind@00407950(void)

{
  int unaff_EBP;
  
  FUN_0040181b((undefined4 *)(*(int *)(unaff_EBP + -0x10) + 4));
  return;
}
