
void __thiscall FUN_00402e7e(void *this,uint *param_1,byte *param_2)

{
  undefined4 uVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  exception local_2c [12];
  void *local_20;
  uint local_18;
  uint local_14;
  uint local_10;
  uint local_c;
  int local_8;
  
  if (*(char *)((int)this + 4) != '\0') {
    local_14 = ((uint)(byte)*param_1 << 0x18 | (uint)*(byte *)((int)param_1 + 1) << 0x10 |
                (uint)*(byte *)((int)param_1 + 2) << 8 | (uint)*(byte *)((int)param_1 + 3)) ^
               *(uint *)((int)this + 8);
    local_10 = ((uint)(byte)param_1[1] << 0x18 | (uint)*(byte *)((int)param_1 + 5) << 0x10 |
                (uint)*(byte *)((int)param_1 + 6) << 8 | (uint)*(byte *)((int)param_1 + 7)) ^
               *(uint *)((int)this + 0xc);
    uVar4 = ((uint)(byte)param_1[2] << 0x18 | (uint)*(byte *)((int)param_1 + 9) << 0x10 |
             (uint)*(byte *)((int)param_1 + 10) << 8 | (uint)*(byte *)((int)param_1 + 0xb)) ^
            *(uint *)((int)this + 0x10);
    iVar3 = *(int *)((int)this + 0x410);
    local_c = ((uint)CONCAT11(*(undefined1 *)((int)param_1 + 0xe),
                              *(undefined1 *)((int)param_1 + 0xf)) |
              (uint)(byte)param_1[3] << 0x18 | (uint)*(byte *)((int)param_1 + 0xd) << 0x10) ^
              *(uint *)((int)this + 0x14);
    if (1 < iVar3) {
      local_8 = iVar3 + -1;
      param_1 = (uint *)((int)this + 0x30);
      local_18 = uVar4;
      do {
        uVar5 = *(uint *)(&DAT_004093fc + (local_c >> 8 & 0xff) * 4) ^
                *(uint *)(&DAT_00408ffc + (local_18 >> 0x10 & 0xff) * 4) ^
                *(uint *)(&DAT_00408bfc + (local_10 >> 0x18) * 4) ^
                *(uint *)(&DAT_004097fc + (local_14 & 0xff) * 4) ^ param_1[-1];
        uVar4 = *(uint *)(&DAT_00408ffc + (local_c >> 0x10 & 0xff) * 4) ^
                *(uint *)(&DAT_00408bfc + (local_18 >> 0x18) * 4) ^
                *(uint *)(&DAT_004093fc + (local_14 >> 8 & 0xff) * 4) ^
                *(uint *)(&DAT_004097fc + (local_10 & 0xff) * 4) ^ *param_1;
        uVar2 = *(uint *)(&DAT_00408bfc + (local_c >> 0x18) * 4) ^
                *(uint *)(&DAT_004093fc + (local_10 >> 8 & 0xff) * 4) ^
                *(uint *)(&DAT_00408ffc + (local_14 >> 0x10 & 0xff) * 4) ^
                *(uint *)(&DAT_004097fc + (local_18 & 0xff) * 4) ^ param_1[1];
        local_14 = *(uint *)(&DAT_004093fc + (local_18 >> 8 & 0xff) * 4) ^
                   *(uint *)(&DAT_00408ffc + (local_10 >> 0x10 & 0xff) * 4) ^
                   *(uint *)(&DAT_00408bfc + (local_14 >> 0x18) * 4) ^
                   *(uint *)(&DAT_004097fc + (local_c & 0xff) * 4) ^ param_1[-2];
        local_8 = local_8 + -1;
        param_1 = param_1 + 8;
        local_18 = uVar4;
        local_10 = uVar5;
        local_c = uVar2;
      } while (local_8 != 0);
    }
    iVar3 = iVar3 * 0x20;
    uVar1 = *(undefined4 *)(iVar3 + 8 + (int)this);
    *param_2 = (&DAT_004089fc)[local_14 >> 0x18] ^ (byte)((uint)uVar1 >> 0x18);
    param_2[1] = (&DAT_004089fc)[local_10 >> 0x10 & 0xff] ^ (byte)((uint)uVar1 >> 0x10);
    param_2[2] = (&DAT_004089fc)[uVar4 >> 8 & 0xff] ^ (byte)((uint)uVar1 >> 8);
    local_8._0_1_ = (byte)uVar1;
    param_2[3] = (&DAT_004089fc)[local_c & 0xff] ^ (byte)local_8;
    uVar1 = *(undefined4 *)((int)this + iVar3 + 0xc);
    param_2[4] = (&DAT_004089fc)[local_10 >> 0x18] ^ (byte)((uint)uVar1 >> 0x18);
    param_2[5] = (&DAT_004089fc)[uVar4 >> 0x10 & 0xff] ^ (byte)((uint)uVar1 >> 0x10);
    param_2[6] = (&DAT_004089fc)[local_c >> 8 & 0xff] ^ (byte)((uint)uVar1 >> 8);
    local_8._0_1_ = (byte)uVar1;
    param_2[7] = (&DAT_004089fc)[local_14 & 0xff] ^ (byte)local_8;
    uVar1 = *(undefined4 *)((int)this + iVar3 + 0x10);
    param_2[8] = (&DAT_004089fc)[uVar4 >> 0x18] ^ (byte)((uint)uVar1 >> 0x18);
    param_2[9] = (&DAT_004089fc)[local_c >> 0x10 & 0xff] ^ (byte)((uint)uVar1 >> 0x10);
    param_2[10] = (&DAT_004089fc)[local_14 >> 8 & 0xff] ^ (byte)((uint)uVar1 >> 8);
    local_8._0_1_ = (byte)uVar1;
    param_2[0xb] = (&DAT_004089fc)[local_10 & 0xff] ^ (byte)local_8;
    uVar1 = *(undefined4 *)((int)this + iVar3 + 0x14);
    param_2[0xc] = (&DAT_004089fc)[local_c >> 0x18] ^ (byte)((uint)uVar1 >> 0x18);
    param_2[0xd] = (&DAT_004089fc)[local_14 >> 0x10 & 0xff] ^ (byte)((uint)uVar1 >> 0x10);
    param_2[0xe] = (&DAT_004089fc)[local_10 >> 8 & 0xff] ^ (byte)((uint)uVar1 >> 8);
    local_8._0_1_ = (byte)uVar1;
    param_2[0xf] = (&DAT_004089fc)[uVar4 & 0xff] ^ (byte)local_8;
    return;
  }
  local_20 = this;
  exception::exception(local_2c,&this_0040f570);
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_2c,(ThrowInfo *)&pThrowInfo_0040d570);
}
