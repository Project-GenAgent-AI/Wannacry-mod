
void FUN_0040792a(void)

{
  _controlfp(0x10000,0x30000);
  return;
}

