
void __thiscall FUN_004031bc(void *this,byte *param_1,byte *param_2)

{
  undefined4 uVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint *puVar5;
  uint uVar6;
  uint uVar7;
  exception local_30 [16];
  void *local_20;
  uint local_14;
  uint local_10;
  uint local_c;
  int local_8;
  
  if (*(char *)((int)this + 4) != '\0') {
    uVar4 = ((uint)*param_1 << 0x18 | (uint)param_1[1] << 0x10 | (uint)param_1[2] << 8 |
            (uint)param_1[3]) ^ *(uint *)((int)this + 0x1e8);
    local_14 = ((uint)param_1[4] << 0x18 | (uint)param_1[5] << 0x10 | (uint)param_1[6] << 8 |
               (uint)param_1[7]) ^ *(uint *)((int)this + 0x1ec);
    local_10 = ((uint)param_1[8] << 0x18 | (uint)param_1[9] << 0x10 | (uint)param_1[10] << 8 |
               (uint)param_1[0xb]) ^ *(uint *)((int)this + 0x1f0);
    iVar3 = *(int *)((int)this + 0x410);
    local_c = ((uint)CONCAT11(param_1[0xe],param_1[0xf]) |
              (uint)param_1[0xc] << 0x18 | (uint)param_1[0xd] << 0x10) ^ *(uint *)((int)this + 500);
    if (1 < iVar3) {
      puVar5 = (uint *)((int)this + 0x210);
      local_8 = iVar3 + -1;
      do {
        uVar7 = *(uint *)(&DAT_0040a3fc + (local_c >> 8 & 0xff) * 4) ^
                *(uint *)(&DAT_00409bfc + (local_14 >> 0x18) * 4) ^
                *(uint *)(&DAT_00409ffc + (uVar4 >> 0x10 & 0xff) * 4) ^
                *(uint *)(&DAT_0040a7fc + (local_10 & 0xff) * 4) ^ puVar5[-1];
        uVar2 = *(uint *)(&DAT_00409bfc + (local_10 >> 0x18) * 4) ^
                *(uint *)(&DAT_00409ffc + (local_14 >> 0x10 & 0xff) * 4) ^
                *(uint *)(&DAT_0040a3fc + (uVar4 >> 8 & 0xff) * 4) ^
                *(uint *)(&DAT_0040a7fc + (local_c & 0xff) * 4) ^ *puVar5;
        uVar6 = *(uint *)(&DAT_00409bfc + (local_c >> 0x18) * 4) ^
                *(uint *)(&DAT_00409ffc + (local_10 >> 0x10 & 0xff) * 4) ^
                *(uint *)(&DAT_0040a3fc + (local_14 >> 8 & 0xff) * 4) ^
                *(uint *)(&DAT_0040a7fc + (uVar4 & 0xff) * 4) ^ puVar5[1];
        uVar4 = *(uint *)(&DAT_00409ffc + (local_c >> 0x10 & 0xff) * 4) ^
                *(uint *)(&DAT_0040a3fc + (local_10 >> 8 & 0xff) * 4) ^
                *(uint *)(&DAT_00409bfc + (uVar4 >> 0x18) * 4) ^
                *(uint *)(&DAT_0040a7fc + (local_14 & 0xff) * 4) ^ puVar5[-2];
        puVar5 = puVar5 + 8;
        local_8 = local_8 + -1;
        local_14 = uVar7;
        local_10 = uVar2;
        local_c = uVar6;
      } while (local_8 != 0);
    }
    iVar3 = iVar3 * 0x20;
    uVar1 = *(undefined4 *)(iVar3 + 0x1e8 + (int)this);
    *param_2 = (&DAT_00408afc)[uVar4 >> 0x18] ^ (byte)((uint)uVar1 >> 0x18);
    param_2[1] = (&DAT_00408afc)[local_c >> 0x10 & 0xff] ^ (byte)((uint)uVar1 >> 0x10);
    param_2[2] = (&DAT_00408afc)[local_10 >> 8 & 0xff] ^ (byte)((uint)uVar1 >> 8);
    local_8._0_1_ = (byte)uVar1;
    param_2[3] = (&DAT_00408afc)[local_14 & 0xff] ^ (byte)local_8;
    uVar1 = *(undefined4 *)((int)this + iVar3 + 0x1ec);
    param_2[4] = (&DAT_00408afc)[local_14 >> 0x18] ^ (byte)((uint)uVar1 >> 0x18);
    param_2[5] = (&DAT_00408afc)[uVar4 >> 0x10 & 0xff] ^ (byte)((uint)uVar1 >> 0x10);
    param_2[6] = (&DAT_00408afc)[local_c >> 8 & 0xff] ^ (byte)((uint)uVar1 >> 8);
    local_8._0_1_ = (byte)uVar1;
    param_2[7] = (&DAT_00408afc)[local_10 & 0xff] ^ (byte)local_8;
    uVar1 = *(undefined4 *)((int)this + iVar3 + 0x1f0);
    param_2[8] = (&DAT_00408afc)[local_10 >> 0x18] ^ (byte)((uint)uVar1 >> 0x18);
    param_2[9] = (&DAT_00408afc)[local_14 >> 0x10 & 0xff] ^ (byte)((uint)uVar1 >> 0x10);
    param_2[10] = (&DAT_00408afc)[uVar4 >> 8 & 0xff] ^ (byte)((uint)uVar1 >> 8);
    local_8._0_1_ = (byte)uVar1;
    param_2[0xb] = (&DAT_00408afc)[local_c & 0xff] ^ (byte)local_8;
    uVar1 = *(undefined4 *)((int)this + iVar3 + 500);
    param_2[0xc] = (&DAT_00408afc)[local_c >> 0x18] ^ (byte)((uint)uVar1 >> 0x18);
    param_2[0xd] = (&DAT_00408afc)[local_10 >> 0x10 & 0xff] ^ (byte)((uint)uVar1 >> 0x10);
    param_2[0xe] = (&DAT_00408afc)[local_14 >> 8 & 0xff] ^ (byte)((uint)uVar1 >> 8);
    local_8._0_1_ = (byte)uVar1;
    param_2[0xf] = (&DAT_00408afc)[uVar4 & 0xff] ^ (byte)local_8;
    return;
  }
  local_20 = this;
  exception::exception(local_30,&this_0040f570);
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_30,(ThrowInfo *)&pThrowInfo_0040d570);
}
