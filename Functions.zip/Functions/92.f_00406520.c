
int __cdecl FUN_00406520(undefined4 *param_1)

{
  int iVar1;
  
  if (param_1 == (undefined4 *)0x0) {
    iVar1 = -0x66;
  }
  else if ((param_1[6] == 0) || (param_1[4] + 1 == param_1[1])) {
    iVar1 = -100;
  }
  else {
    param_1[4] = param_1[4] + 1;
    param_1[5] = param_1[5] + param_1[0x14] + param_1[0x13] + 0x2e + param_1[0x12];
    iVar1 = FUN_004061e0(param_1,param_1 + 10,param_1 + 0x1e,(void *)0x0,0,(void *)0x0,0,(void *)0x0
                         ,0);
    param_1[6] = (uint)(iVar1 == 0);
  }
  return iVar1;
}
