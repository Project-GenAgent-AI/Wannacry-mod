
int * __thiscall FUN_00406b8e(void *this,LPCSTR param_1,undefined4 param_2,int param_3)

{
  char cVar1;
  size_t sVar2;
  DWORD DVar3;
  char *pcVar4;
  undefined4 *puVar5;
  int *local_8;
  
                    /* WARNING: Load size is inaccurate */
  if ((*this == 0) && (*(int *)((int)this + 4) == -1)) {
    pcVar4 = (char *)((int)this + 0x140);
    local_8 = (int *)this;
    GetCurrentDirectoryA(0x104,pcVar4);
    sVar2 = strlen(pcVar4);
    cVar1 = *(char *)(sVar2 + 0x13f + (int)this);
    if ((cVar1 != '\\') && (cVar1 != '/')) {
      strcat(pcVar4,(char *)&_Source_0040f818);
    }
    if ((param_3 == 1) && (DVar3 = SetFilePointer(param_1,0,(PLONG)0x0,1), DVar3 == 0xffffffff)) {
      local_8 = (int *)0x2000000;
    }
    else {
      pcVar4 = FUN_00405bae(param_1,param_2,param_3,&local_8);
      if (pcVar4 != (char *)0x0) {
        puVar5 = FUN_00405fe2(pcVar4);
        *(undefined4 **)this = puVar5;
        local_8 = (int *)((-(uint)(puVar5 != (undefined4 *)0x0) & 0xfffffe00) + 0x200);
      }
    }
  }
  else {
    local_8 = (int *)0x1000000;
  }
  return local_8;
}
