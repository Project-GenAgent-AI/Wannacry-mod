
void __cdecl FUN_00405e6b(char *param_1,int *param_2)

{
  char *pcVar1;
  char *pcVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  
  pcVar1 = param_1;
  iVar3 = FUN_00405def(param_1,(uint *)&param_1);
  pcVar2 = param_1;
  if (iVar3 == 0) {
    iVar3 = FUN_00405def(pcVar1,(uint *)&param_1);
  }
  iVar4 = (int)param_1 * 0x100;
  if (iVar3 == 0) {
    iVar3 = FUN_00405def(pcVar1,(uint *)&param_1);
  }
  iVar5 = (int)param_1 * 0x10000;
  if ((iVar3 == 0) && (iVar3 = FUN_00405def(pcVar1,(uint *)&param_1), iVar3 == 0)) {
    *param_2 = (int)(pcVar2 + (int)param_1 * 0x1000000 + iVar5 + iVar4);
    return;
  }
  *param_2 = 0;
  return;
}
