
undefined4 __thiscall FUN_00401437(void *this,LPCSTR param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  HGLOBAL pvVar2;
  
  iVar1 = FUN_00401861((void *)((int)this + 4),param_1);
  if (iVar1 != 0) {
    if (param_1 != (LPCSTR)0x0) {
      FUN_00401861((void *)((int)this + 0x2c),(LPCSTR)0x0);
    }
    pvVar2 = GlobalAlloc(0,0x100000);
    *(HGLOBAL *)((int)this + 0x4c8) = pvVar2;
    if (pvVar2 != (HGLOBAL)0x0) {
      pvVar2 = GlobalAlloc(0,0x100000);
      *(HGLOBAL *)((int)this + 0x4cc) = pvVar2;
      if (pvVar2 != (HGLOBAL)0x0) {
        *(undefined4 *)((int)this + 0x4d4) = param_2;
        *(undefined4 *)((int)this + 0x4d0) = param_3;
        return 1;
      }
    }
  }
  return 0;
}
