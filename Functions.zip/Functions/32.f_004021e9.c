
uint * __cdecl
FUN_004021e9(short *param_1,uint param_2,undefined *param_3,undefined *param_4,uint param_5,
            undefined *param_6,uint param_7,uint param_8)

{
  bool bVar1;
  int iVar2;
  HMODULE pHVar3;
  code *pcVar4;
  uint uVar5;
  HANDLE hHeap;
  uint *puVar6;
  void *_Dst;
  undefined3 extraout_var;
  undefined3 extraout_var_00;
  int *piVar7;
  uint uVar8;
  int *piVar9;
  DWORD DVar10;
  SIZE_T dwBytes;
  undefined1 local_2c [4];
  uint local_28;
  uint local_8;
  
  local_8 = 0;
  iVar2 = FUN_00402457(param_2,0x40);
  if (iVar2 == 0) {
    return (uint *)0x0;
  }
  if (*param_1 == 0x5a4d) {
    iVar2 = FUN_00402457(param_2,*(int *)(param_1 + 0x1e) + 0xf8);
    if (iVar2 == 0) {
      return (uint *)0x0;
    }
    piVar9 = (int *)(*(int *)(param_1 + 0x1e) + (int)param_1);
    if (((*piVar9 == 0x4550) && ((short)piVar9[1] == 0x14c)) && ((piVar9[0xe] & 1U) == 0)) {
      uVar8 = (uint)*(ushort *)((int)piVar9 + 6);
      if (uVar8 != 0) {
        piVar7 = (int *)((int)piVar9 + *(ushort *)(piVar9 + 5) + 0x24);
        do {
          uVar5 = piVar7[1];
          if (uVar5 == 0) {
            uVar5 = piVar9[0xe];
          }
          if (local_8 < *piVar7 + uVar5) {
            local_8 = *piVar7 + uVar5;
          }
          piVar7 = piVar7 + 10;
          uVar8 = uVar8 - 1;
        } while (uVar8 != 0);
      }
      pHVar3 = GetModuleHandleA(s_kernel32.dll_0040ebe8);
      if (pHVar3 == (HMODULE)0x0) {
        return (uint *)0x0;
      }
      pcVar4 = (code *)(*(code *)param_6)(pHVar3,s_GetNativeSystemInfo_0040f55c,0);
      if (pcVar4 == (code *)0x0) {
        return (uint *)0x0;
      }
      (*pcVar4)(local_2c);
      uVar8 = piVar9[0x14] + -1 + local_28 & ~(local_28 - 1);
      if (uVar8 == ((local_28 - 1) + local_8 & ~(local_28 - 1))) {
        uVar5 = (*(code *)param_3)(piVar9[0xd],uVar8,0x3000,4,param_8);
        if ((uVar5 != 0) || (uVar5 = (*(code *)param_3)(0,uVar8,0x3000,4,param_8), uVar5 != 0)) {
          dwBytes = 0x3c;
          DVar10 = 8;
          hHeap = GetProcessHeap();
          puVar6 = (uint *)HeapAlloc(hHeap,DVar10,dwBytes);
          if (puVar6 != (uint *)0x0) {
            puVar6[1] = uVar5;
            puVar6[5] = (*(ushort *)((int)piVar9 + 0x16) & 0x2000) >> 0xd;
            puVar6[7] = (uint)param_3;
            puVar6[8] = (uint)param_4;
            puVar6[9] = param_5;
            puVar6[10] = (uint)param_6;
            puVar6[0xb] = param_7;
            puVar6[0xc] = param_8;
            puVar6[0xe] = local_28;
            iVar2 = FUN_00402457(param_2,piVar9[0x15]);
            if (iVar2 != 0) {
              _Dst = (void *)(*(code *)param_3)(uVar5,piVar9[0x15],0x1000,4,param_8);
              memcpy(_Dst,param_1,piVar9[0x15]);
              iVar2 = *(int *)(param_1 + 0x1e);
              *puVar6 = iVar2 + (int)_Dst;
              *(uint *)(iVar2 + (int)_Dst + 0x34) = uVar5;
              iVar2 = FUN_00402470((int)param_1,param_2,(int)piVar9,(int *)puVar6);
              if (iVar2 != 0) {
                iVar2 = *(int *)(*puVar6 + 0x34) - piVar9[0xd];
                if (iVar2 == 0) {
                  puVar6[6] = 1;
                }
                else {
                  bVar1 = FUN_00402758((int *)puVar6,iVar2);
                  puVar6[6] = CONCAT31(extraout_var,bVar1);
                }
                iVar2 = FUN_004027df(puVar6);
                if (((iVar2 != 0) &&
                    (bVar1 = FUN_0040254b((int *)puVar6), CONCAT31(extraout_var_00,bVar1) != 0)) &&
                   (iVar2 = FUN_0040271d((int *)puVar6), iVar2 != 0)) {
                  iVar2 = *(int *)(*puVar6 + 0x28);
                  if (iVar2 == 0) {
                    puVar6[0xd] = 0;
                    return puVar6;
                  }
                  if (puVar6[5] == 0) {
                    puVar6[0xd] = iVar2 + uVar5;
                    return puVar6;
                  }
                  iVar2 = (*(code *)(iVar2 + uVar5))(uVar5,1,0);
                  if (iVar2 != 0) {
                    puVar6[4] = 1;
                    return puVar6;
                  }
                  SetLastError(0x45a);
                }
              }
            }
            FUN_004029cc((int *)puVar6);
            return (uint *)0x0;
          }
          (*(code *)param_4)(uVar5,0,0x8000,param_8);
        }
        DVar10 = 0xe;
        goto LAB_00402219;
      }
    }
  }
  DVar10 = 0xc1;
LAB_00402219:
  SetLastError(DVar10);
  return (uint *)0x0;
}
