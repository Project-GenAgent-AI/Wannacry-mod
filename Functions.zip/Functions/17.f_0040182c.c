
undefined4 __fastcall FUN_0040182c(int param_1)

{
  int iVar1;
  int iVar2;
  
  iVar2 = 0;
  do {
    iVar1 = (*DAT_0040f894)(param_1 + 4,0,-(uint)(iVar2 != 0) & 0x40f08c,0x18,0xf0000000);
    if (iVar1 != 0) {
      return 1;
    }
    iVar2 = iVar2 + 1;
  } while (iVar2 < 2);
  return 0;
}

