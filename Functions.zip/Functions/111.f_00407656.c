
undefined4 __cdecl FUN_00407656(int *param_1)

{
  int *piVar1;
  
  if (param_1 == (int *)0x0) {
    DAT_0040f938 = 0x10000;
  }
  else {
    if (*param_1 == 1) {
      piVar1 = (int *)param_1[1];
      DAT_0040f938 = FUN_0040747b(piVar1);
      if (piVar1 != (int *)0x0) {
        FUN_00407572((int)piVar1);
        operator_delete(piVar1);
      }
      operator_delete(param_1);
      return DAT_0040f938;
    }
    DAT_0040f938 = 0x80000;
  }
  return DAT_0040f938;
}
