
undefined4 __fastcall FUN_004013ce(int param_1)

{
  undefined1 *puVar1;
  int iVar2;
  int iVar3;
  
  FUN_004018b9(param_1 + 4);
  FUN_004018b9(param_1 + 0x2c);
  puVar1 = *(undefined1 **)(param_1 + 0x4c8);
  iVar3 = 0x100000;
  if (puVar1 != (undefined1 *)0x0) {
    iVar2 = 0x100000;
    do {
      *puVar1 = 0;
      puVar1 = puVar1 + 1;
      iVar2 = iVar2 + -1;
    } while (iVar2 != 0);
    GlobalFree(*(HGLOBAL *)(param_1 + 0x4c8));
    *(undefined4 *)(param_1 + 0x4c8) = 0;
  }
  puVar1 = *(undefined1 **)(param_1 + 0x4cc);
  if (puVar1 != (undefined1 *)0x0) {
    do {
      *puVar1 = 0;
      puVar1 = puVar1 + 1;
      iVar3 = iVar3 + -1;
    } while (iVar3 != 0);
    GlobalFree(*(HGLOBAL *)(param_1 + 0x4cc));
    *(undefined4 *)(param_1 + 0x4cc) = 0;
  }
  return 1;
}
