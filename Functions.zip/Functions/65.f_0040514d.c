
undefined4 __cdecl
FUN_0040514d(int param_1,int param_2,int param_3,int param_4,int param_5,int *param_6)

{
  byte bVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  byte *pbVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  byte *pbVar12;
  undefined4 uStack_2c;
  byte *local_14;
  byte *local_10;
  byte *local_c;
  uint local_8;
  
  piVar3 = param_6;
  local_10 = *(byte **)(param_5 + 0x34);
  uVar9 = *(uint *)(param_5 + 0x1c);
  local_c = (byte *)*param_6;
  local_8 = param_6[1];
  param_6 = *(int **)(param_5 + 0x20);
  if (local_10 < *(byte **)(param_5 + 0x30)) {
    local_14 = *(byte **)(param_5 + 0x30) + (-1 - (int)local_10);
  }
  else {
    local_14 = (byte *)(*(int *)(param_5 + 0x2c) - (int)local_10);
  }
  uVar8 = *(uint *)(&DAT_0040bca8 + param_1 * 4);
  uVar2 = *(uint *)(&DAT_0040bca8 + param_2 * 4);
  do {
    for (; uVar9 < 0x14; uVar9 = uVar9 + 8) {
      local_8 = local_8 - 1;
      param_6 = (int *)((uint)param_6 | (uint)*local_c << ((byte)uVar9 & 0x1f));
      local_c = local_c + 1;
    }
    pbVar12 = (byte *)(param_3 + (uVar8 & (uint)param_6) * 8);
    bVar1 = *pbVar12;
LAB_004051d5:
    uVar6 = (uint)bVar1;
    if (uVar6 != 0) {
      param_6 = (int *)((uint)param_6 >> (pbVar12[1] & 0x1f));
      uVar9 = uVar9 - pbVar12[1];
      if ((bVar1 & 0x10) != 0) {
        uVar6 = uVar6 & 0xf;
        uVar10 = *(uint *)(&DAT_0040bca8 + uVar6 * 4) & (uint)param_6;
        param_6 = (int *)((uint)param_6 >> (sbyte)uVar6);
        uVar10 = uVar10 + *(int *)(pbVar12 + 4);
        for (uVar9 = uVar9 - uVar6; uVar9 < 0xf; uVar9 = uVar9 + 8) {
          local_8 = local_8 - 1;
          param_6 = (int *)((uint)param_6 | (uint)*local_c << ((byte)uVar9 & 0x1f));
          local_c = local_c + 1;
        }
        uVar6 = uVar2 & (uint)param_6;
        iVar4 = param_4 + uVar6 * 8;
        param_6 = (int *)((uint)param_6 >> (*(byte *)(iVar4 + 1) & 0x1f));
        uVar9 = uVar9 - *(byte *)(iVar4 + 1);
        bVar1 = *(byte *)(param_4 + uVar6 * 8);
        while ((bVar1 & 0x10) == 0) {
          if ((bVar1 & 0x40) != 0) {
            piVar3[6] = (int)s_invalid_distance_code_0040f618;
            uVar8 = piVar3[1] - local_8;
            if (uVar9 >> 3 < piVar3[1] - local_8) {
              uVar8 = uVar9 >> 3;
            }
            uStack_2c = 0xfffffffd;
            goto LAB_004053ed;
          }
          iVar7 = (*(uint *)(&DAT_0040bca8 + (uint)bVar1 * 4) & (uint)param_6) + *(int *)(iVar4 + 4)
          ;
          pbVar12 = (byte *)(iVar4 + iVar7 * 8);
          iVar4 = iVar4 + iVar7 * 8;
          param_6 = (int *)((uint)param_6 >> (*(byte *)(iVar4 + 1) & 0x1f));
          uVar9 = uVar9 - *(byte *)(iVar4 + 1);
          bVar1 = *pbVar12;
        }
        uVar6 = bVar1 & 0xf;
        for (; uVar9 < uVar6; uVar9 = uVar9 + 8) {
          local_8 = local_8 - 1;
          param_6 = (int *)((uint)param_6 | (uint)*local_c << ((byte)uVar9 & 0x1f));
          local_c = local_c + 1;
        }
        uVar11 = *(uint *)(&DAT_0040bca8 + uVar6 * 4) & (uint)param_6;
        uVar9 = uVar9 - uVar6;
        param_6 = (int *)((uint)param_6 >> (sbyte)uVar6);
        local_14 = local_14 + -uVar10;
        pbVar5 = local_10 + -(uVar11 + *(int *)(iVar4 + 4));
        pbVar12 = *(byte **)(param_5 + 0x28);
        if (pbVar5 < pbVar12) {
          do {
            pbVar5 = pbVar5 + (*(int *)(param_5 + 0x2c) - (int)pbVar12);
          } while (pbVar5 < pbVar12);
          uVar6 = *(int *)(param_5 + 0x2c) - (int)pbVar5;
          if (uVar6 < uVar10) {
            param_1 = uVar10 - uVar6;
            do {
              *local_10 = *pbVar5;
              local_10 = local_10 + 1;
              pbVar5 = pbVar5 + 1;
              uVar6 = uVar6 - 1;
            } while (uVar6 != 0);
            pbVar12 = *(byte **)(param_5 + 0x28);
            do {
              *local_10 = *pbVar12;
              local_10 = local_10 + 1;
              pbVar12 = pbVar12 + 1;
              param_1 = param_1 + -1;
            } while (param_1 != 0);
          }
          else {
            *local_10 = *pbVar5;
            local_10[1] = pbVar5[1];
            local_10 = local_10 + 2;
            pbVar5 = pbVar5 + 2;
            param_1 = uVar10 - 2;
            do {
              *local_10 = *pbVar5;
              local_10 = local_10 + 1;
              pbVar5 = pbVar5 + 1;
              param_1 = param_1 + -1;
            } while (param_1 != 0);
          }
        }
        else {
          *local_10 = *pbVar5;
          local_10[1] = pbVar5[1];
          local_10 = local_10 + 2;
          pbVar5 = pbVar5 + 2;
          param_1 = uVar10 - 2;
          do {
            *local_10 = *pbVar5;
            local_10 = local_10 + 1;
            pbVar5 = pbVar5 + 1;
            param_1 = param_1 + -1;
          } while (param_1 != 0);
        }
        goto LAB_0040536f;
      }
      if ((bVar1 & 0x40) == 0) break;
      if ((bVar1 & 0x20) == 0) {
        piVar3[6] = (int)s_invalid_literal/length_code_0040f630;
        uVar8 = piVar3[1] - local_8;
        if (uVar9 >> 3 < piVar3[1] - local_8) {
          uVar8 = uVar9 >> 3;
        }
        uStack_2c = 0xfffffffd;
      }
      else {
        uVar8 = piVar3[1] - local_8;
        if (uVar9 >> 3 < piVar3[1] - local_8) {
          uVar8 = uVar9 >> 3;
        }
        uStack_2c = 1;
      }
      goto LAB_004053ed;
    }
    param_6 = (int *)((uint)param_6 >> (pbVar12[1] & 0x1f));
    uVar9 = uVar9 - pbVar12[1];
    local_14 = local_14 + -1;
    *local_10 = pbVar12[4];
    local_10 = local_10 + 1;
LAB_0040536f:
    if ((local_14 < (byte *)0x102) || (local_8 < 10)) {
      uVar8 = piVar3[1] - local_8;
      if (uVar9 >> 3 < piVar3[1] - local_8) {
        uVar8 = uVar9 >> 3;
      }
      uStack_2c = 0;
LAB_004053ed:
      *(int **)(param_5 + 0x20) = param_6;
      *(uint *)(param_5 + 0x1c) = uVar9 + uVar8 * -8;
      piVar3[1] = uVar8 + local_8;
      iVar4 = *piVar3;
      *piVar3 = (int)local_c - uVar8;
      piVar3[2] = piVar3[2] + (((int)local_c - uVar8) - iVar4);
      *(byte **)(param_5 + 0x34) = local_10;
      return uStack_2c;
    }
  } while( true );
  pbVar12 = pbVar12 + ((*(uint *)(&DAT_0040bca8 + uVar6 * 4) & (uint)param_6) +
                      *(int *)(pbVar12 + 4)) * 8;
  bVar1 = *pbVar12;
  goto LAB_004051d5;
}
