
void __fastcall FUN_00402a6f(undefined4 *param_1)

{
  *param_1 = &PTR_FUN_0040bc7c;
  return;
}
