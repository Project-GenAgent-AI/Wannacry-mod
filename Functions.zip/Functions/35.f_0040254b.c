
bool __cdecl FUN_0040254b(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  bool bVar4;
  undefined3 extraout_var;
  undefined3 extraout_var_00;
  uint uVar5;
  uint local_20;
  uint local_1c;
  int local_18;
  uint local_14;
  undefined4 local_10;
  int local_c;
  uint local_8;
  
  piVar3 = param_1;
  iVar1 = *(ushort *)(*param_1 + 0x14) + 0x18 + *param_1;
  local_20 = *(uint *)(iVar1 + 8);
  local_1c = ~(param_1[0xe] - 1U) & local_20;
  local_18 = FUN_0040264f(param_1,iVar1);
  local_14 = *(uint *)(iVar1 + 0x24);
  local_10 = 0;
  iVar2 = *param_1;
  param_1 = (int *)0x1;
  if (1 < *(ushort *)(iVar2 + 6)) {
    do {
      local_8 = *(uint *)(iVar1 + 0x30);
      uVar5 = ~(piVar3[0xe] - 1U) & local_8;
      local_c = FUN_0040264f(piVar3,iVar1 + 0x28);
      if ((local_1c == uVar5) || (uVar5 < local_18 + local_20)) {
        uVar5 = *(uint *)(iVar1 + 0x4c);
        if (((uVar5 & 0x2000000) == 0) || ((local_14 & 0x2000000) == 0)) {
          local_14 = (uVar5 | local_14) & 0xfdffffff;
        }
        else {
          local_14 = local_14 | uVar5;
        }
        local_18 = (local_c - local_20) + local_8;
      }
      else {
        bVar4 = FUN_0040267b(piVar3,(int *)&local_20);
        if (CONCAT31(extraout_var,bVar4) == 0) {
          return false;
        }
        local_20 = local_8;
        local_18 = local_c;
        local_14 = *(uint *)(iVar1 + 0x4c);
        local_1c = uVar5;
      }
      param_1 = (int *)((int)param_1 + 1);
      iVar1 = iVar1 + 0x28;
    } while ((int)param_1 < (int)(uint)*(ushort *)(*piVar3 + 6));
  }
  local_10 = 1;
  bVar4 = FUN_0040267b(piVar3,(int *)&local_20);
  return CONCAT31(extraout_var_00,bVar4) != 0;
}
