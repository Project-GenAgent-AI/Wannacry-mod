
void FUN_00401e9e(void)

{
  bool bVar1;
  undefined3 extraout_var;
  int iVar2;
  undefined1 local_31c [178];
  char local_26a [602];
  char *local_10 [3];
  
  local_10[0] = s_13AM4VW2dhxYgXeQepoHkHSQuy6NgaEb_0040f488;
  local_10[1] = s_12t9YDPgwueZ9NyMgw519p7AA8isjr6S_0040f464;
  local_10[2] = s_115p7UMMngoj1pMvkpHijcRdfJNXj6Lr_0040f440;
  bVar1 = FUN_00401000(local_31c,1);
  if (CONCAT31(extraout_var,bVar1) != 0) {
    iVar2 = rand();
    strcpy(local_26a,local_10[iVar2 % 3]);
    FUN_00401000(local_31c,0);
  }
  return;
}
