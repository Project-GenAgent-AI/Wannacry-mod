
void FUN_004076c8(void)

{
  undefined1 auStack_c [12];
  
  ExceptionList = auStack_c;
  return;
}
