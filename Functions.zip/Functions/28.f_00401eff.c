
undefined4 __cdecl FUN_00401eff(int param_1)

{
  HANDLE hObject;
  int iVar1;
  char local_68 [100];
  
  sprintf(local_68,(char *)&_Format_0040f4ac,s_Global\MsWinZonesCacheCounterMut_0040f4b4,0);
  iVar1 = 0;
  if (0 < param_1) {
    do {
      hObject = OpenMutexA(0x100000,1,local_68);
      if (hObject != (HANDLE)0x0) {
        CloseHandle(hObject);
        return 1;
      }
      Sleep(1000);
      iVar1 = iVar1 + 1;
    } while (iVar1 < param_1);
  }
  return 0;
}
