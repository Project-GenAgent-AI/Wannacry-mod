
byte __cdecl FUN_004055a3(uint *param_1,byte param_2)

{
  byte bVar1;
  uint uVar2;
  
  uVar2 = FUN_00405588((int)param_1);
  bVar1 = param_2 ^ (byte)uVar2;
  FUN_00405535(param_1,bVar1);
  return bVar1;
}
