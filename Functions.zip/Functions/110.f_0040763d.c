
void __cdecl FUN_0040763d(int *param_1,char *param_2,char *param_3)

{
  FUN_00407603(param_1,param_2,param_3,0,2);
  return;
}
