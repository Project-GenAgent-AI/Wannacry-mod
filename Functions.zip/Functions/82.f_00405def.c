
int __cdecl FUN_00405def(char *param_1,uint *param_2)

{
  uint uVar1;
  int iVar2;
  byte local_5;
  
  uVar1 = FUN_00405d8a(&local_5,1,1,param_1);
  if (uVar1 == 1) {
    *param_2 = (uint)local_5;
    return 0;
  }
  iVar2 = FUN_00405cc7(param_1);
  return -(uint)(iVar2 != 0);
}
