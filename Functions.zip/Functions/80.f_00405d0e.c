
undefined4 __cdecl FUN_00405d0e(char *param_1,int param_2,int param_3)

{
  DWORD dwMoveMethod;
  
  if (*param_1 != '\0') {
    if (param_1[1] != '\0') {
      if (param_3 == 0) {
        dwMoveMethod = 0;
        param_2 = *(int *)(param_1 + 0xc) + param_2;
      }
      else if (param_3 == 1) {
        dwMoveMethod = 1;
      }
      else {
        if (param_3 != 2) {
          return 0x13;
        }
        dwMoveMethod = 2;
      }
      SetFilePointer(*(HANDLE *)(param_1 + 4),param_2,(PLONG)0x0,dwMoveMethod);
      return 0;
    }
    if (*param_1 != '\0') {
      return 0x1d;
    }
  }
  if (param_3 != 0) {
    if (param_3 == 1) {
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + param_2;
      return 0;
    }
    if (param_3 != 2) {
      return 0;
    }
    param_2 = *(int *)(param_1 + 0x18) + param_2;
  }
  *(int *)(param_1 + 0x1c) = param_2;
  return 0;
}

