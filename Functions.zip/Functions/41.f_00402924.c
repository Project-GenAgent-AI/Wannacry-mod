
int __cdecl FUN_00402924(int *param_1,char *param_2)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  ushort *puVar4;
  int iVar5;
  int *piVar6;
  
  iVar1 = param_1[1];
  if (*(int *)(*param_1 + 0x7c) != 0) {
    iVar5 = *(int *)(*param_1 + 0x78);
    iVar3 = *(int *)(iVar5 + 0x18 + iVar1);
    iVar5 = iVar5 + iVar1;
    if ((iVar3 != 0) && (*(int *)(iVar5 + 0x14) != 0)) {
      if ((short)((uint)param_2 >> 0x10) == 0) {
        if (*(uint *)(iVar5 + 0x10) <= ((uint)param_2 & 0xffff)) {
          uVar2 = ((uint)param_2 & 0xffff) - *(uint *)(iVar5 + 0x10);
LAB_004029ba:
          if (uVar2 <= *(uint *)(iVar5 + 0x14)) {
            return *(int *)(*(int *)(iVar5 + 0x1c) + uVar2 * 4 + iVar1) + iVar1;
          }
        }
      }
      else {
        piVar6 = (int *)(*(int *)(iVar5 + 0x20) + iVar1);
        puVar4 = (ushort *)(*(int *)(iVar5 + 0x24) + iVar1);
        param_1 = (int *)0x0;
        if (iVar3 != 0) {
          do {
            iVar3 = _stricmp(param_2,(char *)(*piVar6 + iVar1));
            if (iVar3 == 0) {
              uVar2 = (uint)*puVar4;
              goto LAB_004029ba;
            }
            param_1 = (int *)((int)param_1 + 1);
            piVar6 = piVar6 + 1;
            puVar4 = puVar4 + 1;
          } while (param_1 < *(int **)(iVar5 + 0x18));
        }
      }
    }
  }
  SetLastError(0x7f);
  return 0;
}
