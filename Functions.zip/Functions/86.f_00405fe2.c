
undefined4 * __cdecl FUN_00405fe2(char *param_1)

{
  char *pcVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  char **ppcVar5;
  undefined4 *puVar6;
  char *local_94;
  int local_90;
  int local_8c;
  int local_88;
  int local_78;
  int local_74;
  int local_70 [22];
  undefined4 local_18;
  int local_14;
  int local_10;
  int local_c;
  int local_8;
  
  pcVar1 = param_1;
  if (param_1 == (char *)0x0) {
    return (undefined4 *)0x0;
  }
  param_1 = (char *)0x0;
  iVar2 = FUN_00405edf(pcVar1);
  if (iVar2 == -1) {
    param_1 = (char *)0xffffffff;
  }
  iVar3 = FUN_00405d0e(pcVar1,iVar2,0);
  if (iVar3 != 0) {
    param_1 = (char *)0xffffffff;
  }
  iVar3 = FUN_00405e6b(pcVar1,&local_14);
  if (iVar3 != 0) {
    param_1 = (char *)0xffffffff;
  }
  iVar3 = FUN_00405e27(pcVar1,&local_8);
  if (iVar3 != 0) {
    param_1 = (char *)0xffffffff;
  }
  iVar3 = FUN_00405e27(pcVar1,&local_10);
  if (iVar3 != 0) {
    param_1 = (char *)0xffffffff;
  }
  iVar3 = FUN_00405e27(pcVar1,&local_90);
  if (iVar3 != 0) {
    param_1 = (char *)0xffffffff;
  }
  iVar3 = FUN_00405e27(pcVar1,&local_c);
  if (iVar3 != 0) {
    param_1 = (char *)0xffffffff;
  }
  if (((local_c != local_90) || (local_10 != 0)) || (local_8 != 0)) {
    param_1 = (char *)0xffffff99;
  }
  iVar3 = FUN_00405e6b(pcVar1,&local_74);
  if (iVar3 != 0) {
    param_1 = (char *)0xffffffff;
  }
  iVar3 = FUN_00405e6b(pcVar1,local_70);
  if (iVar3 != 0) {
    param_1 = (char *)0xffffffff;
  }
  iVar3 = FUN_00405e27(pcVar1,&local_8c);
  if (iVar3 != 0) {
    param_1 = (char *)0xffffffff;
  }
  if ((uint)(*(int *)(pcVar1 + 0xc) + iVar2) < (uint)(local_74 + local_70[0])) {
    if (param_1 != (char *)0x0) goto LAB_00406112;
    param_1 = (char *)0xffffff99;
  }
  if (param_1 == (char *)0x0) {
    local_94 = pcVar1;
    local_18 = 0;
    local_88 = ((*(int *)(pcVar1 + 0xc) - local_74) - local_70[0]) + iVar2;
    pcVar1[0xc] = '\0';
    pcVar1[0xd] = '\0';
    pcVar1[0xe] = '\0';
    pcVar1[0xf] = '\0';
    local_78 = iVar2;
    puVar4 = (undefined4 *)malloc(0x80);
    ppcVar5 = &local_94;
    puVar6 = puVar4;
    for (iVar2 = 0x20; iVar2 != 0; iVar2 = iVar2 + -1) {
      *puVar6 = *ppcVar5;
      ppcVar5 = ppcVar5 + 1;
      puVar6 = puVar6 + 1;
    }
    FUN_004064e2(puVar4);
    return puVar4;
  }
LAB_00406112:
  FUN_00405c9f(pcVar1);
  return (undefined4 *)0x0;
}
