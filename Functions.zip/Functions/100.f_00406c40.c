
undefined4 __thiscall FUN_00406c40(void *this,int param_1,undefined4 *param_2)

{
  undefined1 *puVar1;
  uchar uVar2;
  undefined4 *_Src;
  void *pvVar3;
  byte bVar4;
  int iVar5;
  uint uVar6;
  uchar *puVar7;
  int iVar8;
  byte bVar9;
  byte bVar10;
  uchar *_Str;
  longlong lVar11;
  uchar local_284 [260];
  char local_180 [260];
  uint local_7c [4];
  uint local_6c;
  undefined4 local_64;
  undefined4 local_60;
  uint local_48;
  int local_2c;
  _FILETIME local_28;
  _FILETIME local_20;
  void *local_18;
  int local_14;
  uint local_10;
  undefined4 local_c;
  byte local_5;
  
  _Src = param_2;
                    /* WARNING: Load size is inaccurate */
  if ((param_1 < -1) || (*(int *)(*this + 4) <= param_1)) {
    return 0x10000;
  }
  local_18 = this;
  if (*(int *)((int)this + 4) != -1) {
    FUN_00406a97(*this);
  }
  *(undefined4 *)((int)this + 4) = 0xffffffff;
  if (param_1 == *(int *)((int)this + 0x134)) {
    if (param_1 != -1) {
      memcpy(param_2,(void *)((int)this + 8),300);
      return 0;
    }
  }
  else if (param_1 != -1) {
                    /* WARNING: Load size is inaccurate */
    if (param_1 < (int)(*this)[4]) {
      FUN_004064e2(*this);
    }
                    /* WARNING: Load size is inaccurate */
    while ((int)(*this)[4] < param_1) {
      FUN_00406520(*this);
    }
                    /* WARNING: Load size is inaccurate */
    FUN_004064bb(*this,(int *)local_7c,local_180,0x104,(void *)0x0,0,(void *)0x0,0);
                    /* WARNING: Load size is inaccurate */
    iVar5 = FUN_0040657a(*this,&local_2c,&local_14,(int *)&local_10);
    if (iVar5 != 0) {
      return 0x700;
    }
                    /* WARNING: Load size is inaccurate */
    iVar5 = FUN_00405d0e((char *)**this,local_14,0);
    if (iVar5 == 0) {
      local_c = operator_new(local_10);
                    /* WARNING: Load size is inaccurate */
      uVar6 = FUN_00405d8a(local_c,1,local_10,(char *)**this);
      if (uVar6 == local_10) {
                    /* WARNING: Load size is inaccurate */
        *param_2 = *(undefined4 *)(*this + 0x10);
        strcpy((char *)local_284,local_180);
        _Str = local_284;
        while( true ) {
          while( true ) {
            for (; (uVar2 = *_Str, uVar2 != '\0' && (_Str[1] == ':')); _Str = _Str + 2) {
            }
            if ((uVar2 != '\\') && (uVar2 != '/')) break;
            _Str = _Str + 1;
          }
          puVar7 = _mbsstr(_Str,(uchar *)&_Substr_0040f838);
          if ((puVar7 == (uchar *)0x0) &&
             (((puVar7 = _mbsstr(_Str,(uchar *)&_Substr_0040f830), puVar7 == (uchar *)0x0 &&
               (puVar7 = _mbsstr(_Str,(uchar *)&_Substr_0040f828), puVar7 == (uchar *)0x0)) &&
              (puVar7 = _mbsstr(_Str,(uchar *)&_Substr_0040f820), puVar7 == (uchar *)0x0)))) break;
          _Str = puVar7 + 4;
        }
        strcpy((char *)(param_2 + 1),(char *)_Str);
        param_2._3_1_ = 0;
        local_5 = 0;
        bVar9 = ~(byte)(local_48 >> 0x17);
        bVar4 = (byte)(local_48 >> 0x1e);
        local_7c[0] = local_7c[0] >> 8;
        bVar10 = 1;
        if ((((local_7c[0] == 0) || (local_7c[0] == 7)) || (local_7c[0] == 0xb)) ||
           (local_7c[0] == 0xe)) {
          bVar9 = (byte)local_48;
          param_2._3_1_ = (byte)(local_48 >> 1) & 1;
          local_5 = (byte)(local_48 >> 2) & 1;
          bVar4 = (byte)(local_48 >> 4);
          bVar10 = (byte)(local_48 >> 5) & 1;
        }
        iVar5 = 0;
        _Src[0x42] = 0;
        if ((bVar4 & 1) != 0) {
          _Src[0x42] = 0x10;
        }
        if (bVar10 != 0) {
          _Src[0x42] = _Src[0x42] | 0x20;
        }
        if (param_2._3_1_ != 0) {
          _Src[0x42] = _Src[0x42] | 2;
        }
        if ((bVar9 & 1) != 0) {
          _Src[0x42] = _Src[0x42] | 1;
        }
        if (local_5 != 0) {
          _Src[0x42] = _Src[0x42] | 4;
        }
        _Src[0x49] = local_64;
        _Src[0x4a] = local_60;
        local_28 = FUN_00406b23(local_6c >> 0x10,local_6c);
        LocalFileTimeToFileTime(&local_28,&local_20);
        pvVar3 = local_c;
        _Src[0x43] = local_20.dwLowDateTime;
        _Src[0x45] = local_20.dwLowDateTime;
        _Src[0x47] = local_20.dwLowDateTime;
        _Src[0x44] = local_20.dwHighDateTime;
        _Src[0x46] = local_20.dwHighDateTime;
        _Src[0x48] = local_20.dwHighDateTime;
        if (4 < local_10) {
          do {
            uVar6 = (uint)local_c >> 0x10;
            local_c._0_2_ =
                 CONCAT11(*(undefined1 *)((int)pvVar3 + iVar5 + 1),
                          *(undefined1 *)(iVar5 + (int)pvVar3));
            local_c = (void *)(CONCAT22((short)uVar6,(undefined2)local_c) & 0xff00ffff);
            bVar9 = *(byte *)((int)pvVar3 + iVar5 + 2);
            iVar8 = strcmp((char *)&local_c,(char *)&_Str2_0040f81c);
            if (iVar8 == 0) {
              bVar9 = *(byte *)(iVar5 + 4 + (int)pvVar3);
              local_5 = bVar9 >> 2 & 1;
              iVar8 = iVar5 + 5;
              if ((bVar9 & 1) != 0) {
                puVar1 = (undefined1 *)(iVar8 + (int)pvVar3);
                iVar8 = iVar5 + 9;
                lVar11 = FUN_00406b02(CONCAT31(CONCAT21(*(undefined2 *)(puVar1 + 2),
                                                        *(undefined1 *)(iVar5 + 6 + (int)pvVar3)),
                                               *puVar1));
                *(longlong *)(_Src + 0x47) = lVar11;
              }
              if ((bVar9 >> 1 & 1) != 0) {
                iVar5 = iVar8 + 1;
                puVar1 = (undefined1 *)(iVar8 + (int)pvVar3);
                iVar8 = iVar8 + 4;
                lVar11 = FUN_00406b02(CONCAT31(CONCAT21(*(undefined2 *)(puVar1 + 2),
                                                        *(undefined1 *)(iVar5 + (int)pvVar3)),
                                               *puVar1));
                *(longlong *)(_Src + 0x43) = lVar11;
              }
              if (local_5 != 0) {
                lVar11 = FUN_00406b02(CONCAT31(CONCAT21(*(undefined2 *)
                                                         ((undefined1 *)(iVar8 + (int)pvVar3) + 2),
                                                        *(undefined1 *)(iVar8 + 1 + (int)pvVar3)),
                                               *(undefined1 *)(iVar8 + (int)pvVar3)));
                *(longlong *)(_Src + 0x45) = lVar11;
              }
              break;
            }
            iVar5 = iVar5 + 4 + (uint)bVar9;
          } while (iVar5 + 4U < local_10);
        }
        if (pvVar3 != (void *)0x0) {
          operator_delete(pvVar3);
        }
        pvVar3 = local_18;
        memcpy((void *)((int)local_18 + 8),_Src,300);
        *(int *)((int)pvVar3 + 0x134) = param_1;
        return 0;
      }
      operator_delete(local_c);
    }
    return 0x800;
  }
                    /* WARNING: Load size is inaccurate */
  *param_2 = *(undefined4 *)(*this + 4);
  *(undefined1 *)(param_2 + 1) = 0;
  param_2[0x42] = 0;
  param_2[0x43] = 0;
  param_2[0x44] = 0;
  param_2[0x45] = 0;
  param_2[0x46] = 0;
  param_2[0x47] = 0;
  param_2[0x48] = 0;
  param_2[0x49] = 0;
  param_2[0x4a] = 0;
  return 0;
}
