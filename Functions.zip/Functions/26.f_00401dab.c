
undefined4 __cdecl FUN_00401dab(HMODULE param_1)

{
  HRSRC hResInfo;
  HGLOBAL hResData;
  LPVOID pvVar1;
  int *piVar2;
  int iVar3;
  DWORD DVar4;
  int iVar5;
  char *pcVar6;
  int local_130;
  char local_12c [296];
  
  hResInfo = FindResourceA(param_1,(LPCSTR)0x80a,&DAT_0040f43c);
  if (((hResInfo != (HRSRC)0x0) &&
      (hResData = LoadResource(param_1,hResInfo), hResData != (HGLOBAL)0x0)) &&
     (pvVar1 = LockResource(hResData), pvVar1 != (LPVOID)0x0)) {
    SizeofResource(param_1,hResInfo);
    piVar2 = (int *)FUN_004075ad();
    if (piVar2 != (int *)0x0) {
      local_130 = 0;
      pcVar6 = local_12c;
      for (iVar5 = 0x4a; iVar5 != 0; iVar5 = iVar5 + -1) {
        pcVar6[0] = '\0';
        pcVar6[1] = '\0';
        pcVar6[2] = '\0';
        pcVar6[3] = '\0';
        pcVar6 = pcVar6 + 4;
      }
      FUN_004075c4(piVar2,-1,&local_130);
      iVar5 = local_130;
      pcVar6 = (char *)0x0;
      if (0 < local_130) {
        do {
          FUN_004075c4(piVar2,(int)pcVar6,&local_130);
          iVar3 = strcmp(local_12c,s_c.wnry_0040e010);
          if ((iVar3 != 0) || (DVar4 = GetFileAttributesA(local_12c), DVar4 == 0xffffffff)) {
            FUN_0040763d(piVar2,pcVar6,local_12c);
          }
          pcVar6 = pcVar6 + 1;
        } while ((int)pcVar6 < iVar5);
      }
      FUN_00407656(piVar2);
      return 1;
    }
  }
  return 0;
}
